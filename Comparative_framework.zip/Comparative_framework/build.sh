#!/bin/bash

#get current directory
CURRENT_DIR=`pwd`

#build project and install it
mkdir bin

#get current directory
CURRENT_DIR=`pwd`

cd $CURRENT_DIR/src

echo -ne Compilation source file... '\b'

make clean
make

mv performance_evaluation ../bin
mv sensor_simulator ../bin

echo DONE
echo Ready to use

