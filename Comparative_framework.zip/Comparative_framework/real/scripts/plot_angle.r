#!/usr/bin/Rscript

suppressMessages(library(limma))

## Collect arguments
args <- commandArgs(TRUE)
 

 
## Default setting when no arguments passed
if(length(args) < 1) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
      The R Script
 
      Arguments:
      --nb_method=n
	  --input=file_csv
	  --output=file_png  
      --method_name=c(name1,name2)
      --column_name=c(name1,name2)
      --help") 
 
  q(save="no")
}
 
cat("\n")

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

output_file=argsL$output
input_file=argsL$input
method_name <- unlist(strsplit(argsL$method_name, "[,]"))
column_name <- unlist(strsplit(argsL$column_name, "[,]"))
nb_method=argsL$nb_method


png(
  file      = output_file,
  width     = 2000,
  height    = 1200,
  units     = "px",
  res       = NA,
  pointsize = 12
)

par(
  mar      = c(5, 5, 2, 2),
  xaxs     = "i",
  yaxs     = "i",
  cex.axis = 2,
  cex.lab  = 2
)



color_palette <- c("blue","green","red","magenta","cyan","yellow","brown","orange","darkgray")
csv_file <- read.csv(input_file,header=TRUE)
x_axis <- csv_file$index


j<-1
for (i in 1:(nb_method) ) {
	
	if( i == 1 ){
		y_axis_pitch <- read.columns(input_file, column_name[j], sep = ",")
		y_axis_roll <- read.columns(input_file, column_name[j+1], sep = ",")
		y_axis_yaw <- read.columns(input_file, column_name[j+2], sep = ",")
	}else{
		y_axis_pitch <- cbind(y_axis_pitch,read.columns(input_file, column_name[j], sep = ","))
		y_axis_roll <- cbind(y_axis_roll,read.columns(input_file, column_name[j+1], sep = ","))
		y_axis_yaw <- cbind(y_axis_yaw,read.columns(input_file, column_name[j+2], sep = ","))
	}
	
	j <- j+3
}

attach(mtcars)

par(mfrow=c(3,1)) 

matplot (x_axis, y_axis_pitch, type = "l", lty = 1, lwd = 2, pch = NULL,
         col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"),
		 xlab = 	"Samples",
		 ylab = "Pitch angle (in radian)" ,
	)

legend("topright", inset=.05, legend=method_name, pch=1, col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"), horiz=FALSE, cex=1.55)

matplot (x_axis, y_axis_roll, type = "l", lty = 1, lwd = 2, pch = NULL,
         col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"),
		 xlab = 	"Samples",
		 ylab = "Roll angle (in radian)",
	)

legend("topright", inset=.05, legend=method_name, pch=1, col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"), horiz=FALSE, cex=1.55)


matplot (x_axis, y_axis_yaw, type = "l", lty = 1, lwd = 2, pch = NULL,
         col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"),
		 xlab = 	"Samples",
		 ylab = "Yaw angle (in radian)",
	)

legend("topright", inset=.05, legend=method_name, pch=1, col = c("black","blue","green","red","magenta","cyan","yellow","brown","orange","darkgray"), horiz=FALSE, cex=1.55)

dev.off()





























