format long

files_gt = {
    sprintf('%s/results/base_files/gt/imu_1loopDown_gt.csv',dir_name),
    sprintf('%s/results/base_files/gt/imu_2loopsDown_gt.csv',dir_name),
    sprintf('%s/results/base_files/gt/imu_hoveringDown_gt.csv',dir_name),
    sprintf('%s/results/base_files/gt/imu_randomFront_gt.csv',dir_name)};

files_data = { 
    sprintf('%s/dataset/csv_imu/imu_1loopDown.csv',dir_name),
    sprintf('%s/dataset/csv_imu/imu_2loopsDown.csv',dir_name),
    sprintf('%s/dataset/csv_imu/imu_hoveringDown.csv',dir_name),
    sprintf('%s/dataset/csv_imu/imu_randomFront.csv',dir_name)};


files_data_names = { 
'imu_1loopDown',
'imu_2loopsDown',
'imu_hoveringDown',
'imu_randomFront'};

files_data = files_data(:);
files_data_names = files_data_names(:);
files_gt = files_gt(:);
n = size(files_data);

dt = 0.005;
toto = zeros(4,n(1));

addpath('../../FKF');
addpath('../../FKF/quaternion_library');
addpath('../../FKF/linspecer');

nb=n(1);

dq_a = [0.7806,-0.0107,0.0143,-0.6237];

scores = zeros(nb,4);
eul=[0.872664626,0.872664626,0.872664626];
init_quat=eul2quat(eul);
 q=init_quat';

alpha_acc = 0.5;
alpha_gyro = 0.5;
alpha_mag = 0.5;

 
for f=1:nb

    gt_csv_data = csvread(char(files_gt(f)),1,0);
    csv_data = csvread(char(files_data(f)),1,0);
    N=size(csv_data,1);
    
    Tmp_Accelerometer = zeros(1,3);
    Tmp_Magnetometer = zeros(1,3);
    Tmp_Gyroscope = zeros(1,3);
    
    Accelerometer = zeros(N,3);
    Magnetometer = zeros(N,3);
    Gyroscope = zeros(N,3);
    GT_quat = zeros(N,4);
    conv=diag([-1 1 -1]);
    
    N=size(csv_data,1);
    for i=1:N
       tmp_mag_data = (alpha_mag*Tmp_Magnetometer) +  ( (1-alpha_mag)*csv_data(i,11:13)*conv );
       Tmp_Magnetometer = tmp_mag_data;
       Magnetometer(i,:) = tmp_mag_data;

       tmp_acc_data = (alpha_acc*Tmp_Accelerometer) +  ( (1-alpha_acc)*csv_data(i,2:4)*conv );
       Tmp_Accelerometer = tmp_acc_data;
       Accelerometer(i,:) = tmp_acc_data;
       
       tmp_gyro_data = (alpha_gyro*Tmp_Gyroscope) +  ( (1-alpha_gyro)*csv_data(i,5:7)*conv );
       Tmp_Gyroscope = tmp_gyro_data;
       Gyroscope(i,:) = tmp_gyro_data;
       
       
       GT_quat(i,:) = gt_csv_data(i,2:5);
    end
    
    
    
    Sigma_g=0.0011*eye(3);
    Sigma_a=0.01*eye(3);
    Sigma_m=0.01*eye(3);
    
    Pk=0.001*eye(4);
    q=[1;0;0;0];

    quaternion=zeros(N,4);
    quaternion_measurement=zeros(N,4);
    STD=zeros(N,4);
    %dq = [0.6008,-0.0010,0.0177,-0.7960];
    
    
    fkf_time = zeros(N,1);
    for i=1:N
        
        tic;
        q0=q(1);
        q1=q(2);
        q2=q(3);
        q3=q(4);

        wx=Gyroscope(i,1);
        wy=Gyroscope(i,2);
        wz=Gyroscope(i,3);

        Accelerometer(i,:)=Accelerometer(i,:)./norm(Accelerometer(i,:));
        Magnetometer(i,:)=Magnetometer(i,:)./norm(Magnetometer(i,:));

        q_inv = [q(1) q(2:4)'*-1];
        q_mag = [ 0 Magnetometer(i,:)];
        
        q_eb = quatmultiply(q', quatmultiply(q_mag,q_inv));
        mN = sqrt( (q_eb(2)*q_eb(2)) + (q_eb(3)*q_eb(3)) );
        mD = q_eb(3);
        
        %mD=Accelerometer(i,:)*Magnetometer(i,:)';
        %mN=sqrt(1-mD^2);
        
        omega4=[0,-wx,-wy,-wz;
            wx,0,wz,-wy;
            wy,-wz,0,wx;
            wz,wy,-wx,0];

        Phi=eye(4)+dt/2*omega4;

        Dk=[q1 q2 q3;
            -q0 -q3 -q2;
            q2 -q0 -q1;
            -q2 q1 -q0];
        Xi=dt*dt/4*Dk*Sigma_g*Dk';

        [qy, Jacob]=measurement_quaternion_acc_mag(Accelerometer(i,:),Magnetometer(i,:),[mN,0,mD], q);
        qy=qy./norm(qy);

        Eps=Jacob*[Sigma_a,zeros(3,3);zeros(3,3),Sigma_m]*Jacob';

        std=sqrt([Eps(1,1),Eps(2,2),Eps(3,3),Eps(4,4)]);

        q_=q;
        Pk_ = Pk;
        [q , Pk] = kalman_update(q_, qy, Pk_, Phi, Xi, Eps);


        q=q./norm(q);
        
        quaternion(i,:)=q';
        quaternion(i,:)=quatmultiply(q',dq_a)';
        
        if(quaternion(i,1) < 0)
            quaternion(i,:) = quaternion(i,:)*-1;
        end
        quaternion(i,2) = quaternion(i,2)*-1;
        quaternion(i,3) = quaternion(i,3)*-1;
        quaternion(i,4) = quaternion(i,4)*-1;
        
        quaternion_measurement(i,:)=qy';
        STD(i,:)=std; 
       
        toc;
        elapsedTime = toc;
        
        
        fkf_time(i) = elapsedTime;
        
        
    end
    
    
    
    m=500;
    % QAD
    fkf_theta = zeros(N,1);
    for i=1:N
        q_true = GT_quat(i,1:4)'/norm(GT_quat(i,1:4));
        fkf_q_est  = quaternion(i,1:4)/norm(quaternion(i,1:4));

        dot = q_true'*fkf_q_est';
        fkf_theta(i) = acosd( (2.0*dot*dot) - 1.0 );
        
       for j=2:4
            fkf_q_est(j)=fkf_q_est(j)*-1;
       end
    end

     
    %MAE
    fkf_error = zeros(N,1);
    
    for i=1:N
        q_true = GT_quat(i,:);
        fkf_q_est  = quaternion(i,:);
    
        for j=2:4
            fkf_q_est(j)=fkf_q_est(j)*-1;
        end
    
        fkf_dq = quatmultiply(q_true,fkf_q_est);
        fkf_dp = zeros(1,3);

       for j=1:3
            fkf_dp(j)=fkf_dq(j+1);
       end

   
        if fkf_dq(1) < 0.0
            tmp = -4.0/(1.0 + abs(fkf_dq(1)));
        else
            tmp = 4.0/(1.0 + abs(fkf_dq(1)));
        end

        fkf_dp = fkf_dp*tmp;
        fkf_error(i) = rms(fkf_dp);
    end

    mean_time = mean(fkf_time);
    mean_error=mean(fkf_error);
    
    %export
    file_output= sprintf('%s/results/base_files/error/%s_fkf.csv',dir_name,char(files_data_names(f)));
    
    file_output_resume= sprintf('%s/results/fusion/resume_error/%s_resume.csv',dir_name,char(files_data_names(f)));
    
    csvexport=zeros(N,4);
    
    csvexport(:,1)=(0:N-1);
    csvexport(:,2)=fkf_time(:);
    csvexport(:,3)=fkf_error(:);
    csvexport(:,4)=fkf_theta(:);
    csvwrite(file_output,csvexport)
    
    S = fileread(file_output);
    S = ['index,time,error,qad', char(10), S];
    FID = fopen(file_output, 'w');
    if FID == -1, error('Cannot open file %s', file_output); end
    fwrite(FID, S, 'char');
    fclose(FID);
    
    
    %s1
    s1 = mean(fkf_theta);
    
    %s2
    s2 = 1.0/(mean_time*mean_error*10000.0);

    %s3
    m=300;
    T_k=dt;
    s3 = 0.0;
    for k=2:m
        s3 = s3 + ((-1.0/T_k) * log( fkf_error(k)/fkf_error(1) ) );
        T_k = T_k+dt;
    end
    s3 = s3/m;
    s3 = 1/s3;
    
    %s4
    s4=0.0;
    for k=2:N-1
        s4 = s4 + abs(fkf_error(k)-fkf_error(k-1));
    end
    
    scores(f,:) = [s1,s2,s3,s4];
    
    fid = fopen(file_output_resume,'at') ;
    fprintf(fid, 'fkf,%f,%f,%f,%f\n', scores(f,:)); 
    fclose(fid);
    
    file_output_attitude= sprintf('%s/results/base_files/attitude/%s_fkf.csv',dir_name,char(files_data_names(f)));
    tmp_ee = quat2eul(quaternion);
    ee = zeros(size(tmp_ee));
    ee(:,1) = tmp_ee(:,3);
    ee(:,2) = tmp_ee(:,2);
    ee(:,3) = tmp_ee(:,1);
    csvexport_attitude = zeros(N,8);
    csvexport_attitude(:,1)=(0:N-1);
    csvexport_attitude(:,2)=quaternion(:,1);
    csvexport_attitude(:,3)=quaternion(:,2);
    csvexport_attitude(:,4)=quaternion(:,3);
    csvexport_attitude(:,5)=quaternion(:,4);
    csvexport_attitude(:,6)=ee(:,1);
    csvexport_attitude(:,7)=ee(:,2);
    csvexport_attitude(:,8)=ee(:,3);
    
    csvwrite(file_output_attitude,csvexport_attitude)
    
    
    S = fileread(file_output_attitude);
    S = ['index,quat_w,quat_x,quat_y,quat_z,pitch,roll,yaw', char(10), S];
    FID = fopen(file_output_attitude, 'w');
    if FID == -1, error('Cannot open file %s', file_output_attitude); end
    fwrite(FID, S, 'char');
    fclose(FID);
    
    
end



