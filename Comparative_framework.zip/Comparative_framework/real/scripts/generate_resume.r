#!/usr/bin/Rscript

suppressMessages(library(limma))

## Collect arguments
args <- commandArgs(TRUE)


 
## Default setting when no arguments passed
if(length(args) < 1) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
      The R Script
 
      Arguments:    
      --method_name=c(name1,name2)
	  --output=
	  --input=
      --help") 
 
  q(save="no")
}
 
cat("\n")


specify_decimal <- function(x, k) format(round(x, k), nsmall=k)

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

output_file=argsL$output
input_file=argsL$input
method_name <- unlist(strsplit(argsL$method_name, "[,]"))


file.create(as.character(output_file))

nb_method <- length(method_name)

array_lines <- c("method_name,mean_time,mean_error,standard_deviation_error,convergence")

name <- paste(method_name[1],"_error",sep="")

options("scipen"=100, "digits"=10)



for (i in 1:nb_method ) {

		var_T <- 0.02;
		
		error <- read.columns(input_file,paste(method_name[i],"_error",sep="") , sep = ",")
		com_time <- read.columns(input_file,paste(method_name[i],"_time",sep=""), sep = ",")

		mean_time <- mean(com_time[,paste(method_name[i],"_time",sep="")])
		mean_error <- mean(error[,paste(method_name[i],"_error",sep="")])
		sd_error <- sd(error[,paste(method_name[i],"_error",sep="")])
		
		var_N0 <- error[1,paste(method_name[i],"_error",sep="")]
		var_lambda <- 0.0
		wa <- 0.0
		n <-500
		
		for (j in 1:n ){
		
			var_T <- var_T + 0.01
			var_N <- error[var_T/0.01,paste(method_name[i],"_error",sep="")]
			var_lambda <- var_lambda + ((-1.0/var_T)*log(var_N/var_N0))
		}
		
		m <- length(error[,paste(method_name[i],"_error",sep="")]) - 1
		
		for (j in 1:m ){
		
			wa <- wa + abs(error[j+1,paste(method_name[i],"_error",sep="")] - error[j,paste(method_name[i],"_error",sep="")]) 
			
			#if(abs(error[j+1,paste(method_name[i],"_error",sep="")] - error[j,paste(method_name[i],"_error",sep="")]) > 0.002){
			#	wa <- wa + 1
			#}
			

		}
		
		
		var_lambda <- var_lambda/n
		
		line_i <- paste(as.character(method_name[i]),",",mean_time,",",as.character(mean_error),",",as.character(sd_error),",",as.character(abs(var_lambda)),",",as.character(wa),sep="")
		
		array_lines <- cbind(array_lines,line_i)
}


writeLines(array_lines, as.character(output_file))


#write into file



