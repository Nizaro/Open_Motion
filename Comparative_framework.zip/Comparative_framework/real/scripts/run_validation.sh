#!/bin/bash

#get current directory
cd ../
ROOT_DIR=`pwd`

EXE_DIR="$ROOT_DIR/bin"
EXE_PATH="$EXE_DIR/OM_validation"
SCRIPT_PATH="$ROOT_DIR/scripts"
RESULTS_PATH="$ROOT_DIR/results"
PNG_DIR="$ROOT_DIR/results/png"

DATA_DIR="$ROOT_DIR/dataset"


#######################################
# function for float operation
#######################################

float_scale=5

function float_eval()
{
    local stat=0
    local result=0.0
    if [[ $# -gt 0 ]]; then
        result=$(echo "scale=$float_scale; $*" | bc -q 2>/dev/null)
        stat=$?
        if [[ $stat -eq 0  &&  -z "$result" ]]; then stat=1; fi
    fi
    echo $result
    return $stat
}

#############
# Compilation 
#############
cd $EXE_DIR

make clean
make all


rm $RESULTS_PATH/base_files/error/*.csv
rm $RESULTS_PATH/base_files/attitude/*.csv
rm $RESULTS_PATH/base_files/gt/*.csv
rm $RESULTS_PATH/fusion/resume_error/*.csv
rm $RESULTS_PATH/fusion/attitude/*.csv
rm $PNG_DIR/imu/*.png
rm $PNG_DIR/attitude/*.png
rm $PNG_DIR/fusion/*.png
rm $RESULTS_PATH/scores_files/*



echo -ne Plotting sensor data... '\b'
for data in $( ls $DATA_DIR/csv_imu/*.csv); do
	
	#get absolute path
	real_path=`readlink -m $data`

	tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	
	$SCRIPT_PATH/plot_input.r --input=$real_path --output="$PNG_DIR/imu/$name_output.png" > /dev/null 
	
done
echo DONE

echo Computing results... 
for data in $( ls $DATA_DIR/csv_imu/*.csv ); do
	
	#get absolute path
	real_path=`readlink -m $data`
	
	tmp=`echo "$real_path" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	toto=`echo "$name_output" | cut -d'_' -f2`
	
		
	echo "start for $real_path"
	vicon="$DATA_DIR/csv_gt/vicon_"$toto".csv"
	
	$EXE_PATH -i $real_path -g $vicon -o $RESULTS_PATH
	
done
echo DONE


# this works ONLY if matlab is installed
cd $SCRIPT_PATH
matlab  -nodesktop -r "dir_name='"$ROOT_DIR"';fkf_real;exit" > /dev/null
cd $EXE_DIR


#############
# PLOTTING RESULTS 
#############

nb_files=0
index=0
index2=1
nb_method=0


echo -ne Plotting sensor quat... '\b'
for data in $( ls $RESULTS_PATH/base_files/gt/*.csv); do
	
		
	#get absolute path
	real_path=`readlink -m $data`

	tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	array_file[$nb_files]=$name_output
	
	$SCRIPT_PATH/plot_quat.r --input=$real_path --output="$PNG_DIR/imu/$name_output.png" > /dev/null 
	
	nb_files=$(( $nb_files + 1 ))
	
done
echo DONE


echo -ne Plotting results... '\b'
for data in $( ls $RESULTS_PATH/base_files/attitude/*.csv ); do
	
	nb_method=$(( $nb_method + 1 ))
	
	#get absolute path
	real_path=`readlink -m $data`

	tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	
	name_method=`echo "$name_output" | cut -d'_' -f3`
	
	
	$SCRIPT_PATH/plot_quat.r --input=$real_path --output="$PNG_DIR/attitude/$name_output.png" > /dev/null 
	
	
done

echo DONE

nb_method=$(( $nb_method / $nb_files ))


array_method[0]="gt"

for data in $( ls $RESULTS_PATH/base_files/attitude/*.csv ); do

	if [  "$index" -ne "$nb_method" ] 
	then
		#get absolute path
		real_path=`readlink -m $data`

		tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
		name_output=`echo "$tmp" | cut -d'.' -f1`
		name_method=`echo "$name_output" | cut -d'_' -f3`
		echo $name_method
		array_method[$index2]=$name_method

		index2=$(( $index2 + 1 ))
		index=$(( $index + 1 ))
	fi

done


echo -ne fusion results... '\b'


#get first line
first_line='index'
colums="1,"
colums_name=''
method_name=''

for method in ${array_method[@]};do	

	first_line=$first_line','$method'_pitch'
	first_line=$first_line','$method'_roll'
	first_line=$first_line','$method'_heading'
	
	colums_name=$colums_name''$method'_pitch,'
	colums_name=$colums_name''$method'_roll,'
	colums_name=$colums_name''$method'_heading,'
	
	method_name=$method_name''$method','

done

 
 
colums_name=${colums_name::-1}
method_name=${method_name::-1}


int_j=1
int_acc=6


for (( j=1; j<=$index2; j++ ))
do

	for (( l=1; l<=4; l++ ))
	do

		if [ $int_j -eq 4 ]
		then
		   int_j=1
		   int_acc=$(( $int_acc + 5))
		else
		   int_j=$(( $int_j + 1))
		   colums=$colums"$int_acc,"
		   int_acc=$(( $int_acc + 1))
		fi
		
		

	done

done
		  
colums=${colums::-1}

 
 
 for file in ${array_file[@]};do
		
		file_output_name=$file'fusion.csv'
		file_output_name_tmp=$file'tmp.csv'
		files_input=""
		file=${file::-2}

		for method in ${array_method[@]};do	

			case $method in
				*gt*)files_input=$files_input" $RESULTS_PATH/base_files/gt/"$file"gt.csv";;
				*)files_input=$files_input" $RESULTS_PATH/base_files/attitude/"$file''$method".csv";;
			esac 
			
			
		done	
		
		
		#fusion files
		csvjoin $files_input > "$RESULTS_PATH/fusion/attitude/$file_output_name_tmp" 
		csvcut -c $colums $RESULTS_PATH/fusion/attitude/$file_output_name_tmp > "$RESULTS_PATH/fusion/attitude/$file_output_name"
		
		rm $RESULTS_PATH/fusion/attitude/$file_output_name_tmp
		
		sed -i 1d $RESULTS_PATH/fusion/attitude/$file_output_name 
		
		cat <(echo $first_line) $RESULTS_PATH/fusion/attitude/$file_output_name > $RESULTS_PATH/fusion/attitude/$file_output_name.new
		mv $RESULTS_PATH/fusion/attitude/$file_output_name.new $RESULTS_PATH/fusion/attitude/$file_output_name
	
done

echo DONE

echo $method_name


index=$(( $index + 1 ))
echo -ne Plotting euler... '\b'
for data in $( ls $RESULTS_PATH/fusion/attitude/*.csv ); do
	
	#get absolute path
	real_path=`readlink -m $data`

	tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	
	
	$SCRIPT_PATH/plot_angle.r --nb_method=$index --input=$real_path --output="$PNG_DIR/fusion/$name_output.png" --method_name="$method_name" --column_name="$colums_name" > /dev/null
	
done
echo DONE

 
echo -ne Plotting table... '\b'

nb_file=0.0
for data in $( ls $RESULTS_PATH/fusion/resume_error/*.csv ); do

	nb_file=$(float_eval "$nb_file + 1.0")
	
	#get absolute path
	real_path=`readlink -m $data`

	nb_method=`wc -l $real_path`
	nb_method=`echo "$nb_method" | cut -d' ' -f1`
done 

nb_method=$(( nb_method - 1 ))

 # initialize matrix
 for(( i=0;i<$nb_method;i++)) do
     for((j=0;j<4;j++)) do
         scores[$(( i * 4 + j ))]=0.0        
     done
 done



for data in $( ls $RESULTS_PATH/fusion/resume_error/*.csv ); do
	
	#get absolute path
	real_path=`readlink -m $data`

	i=0
	#read all lines of the current file
	while read -r line
	do
	    
        case $line in
		*method*) ;;
		*)
		    #get method name
		    name_method=`echo "$line" | cut -d',' -f1`
		    s1=`echo "$line" | cut -d',' -f2`
		    s2=`echo "$line" | cut -d',' -f3`
		    s3=`echo "$line" | cut -d',' -f4`
		    s4=`echo "$line" | cut -d',' -f5`

			array_name[$i]=$name_method
			
			scores[$(( i * 4 + 0 ))]=$(float_eval "${scores[$(( i * 4 + 0 ))]} + $s1")        
			scores[$(( i * 4 + 1 ))]=$(float_eval "${scores[$(( i * 4 + 1 ))]} + $s2")        
			scores[$(( i * 4 + 2 ))]=$(float_eval "${scores[$(( i * 4 + 2 ))]} + $s3")        
			scores[$(( i * 4 + 3 ))]=$(float_eval "${scores[$(( i * 4 + 3 ))]} + $s4")  
			
			i=$(( i + 1 ));; 
		


			
	    esac
	    
	done < $real_path	


done


## Output the values contained in a simulated 2D manner

echo '\documentclass[12pt]{standalone}
\usepackage{varwidth}

\usepackage[utf8x]{inputenc}
\usepackage[T1]{fontenc}

\usepackage{amsmath, amssymb, graphics, setspace,tabularx}
\newcommand{\mathsym}[1]{{}}
\newcommand{\unicode}[1]{{}}
\newcounter{mathematicapage}

\begin{document}

   \begin{varwidth}{100 in}
			\begin{tabular}{c|cccc}

		  & $s_1$ & $s_2$ & $s_3$ & $s_4$\\
		 \hline' >> $RESULTS_PATH"/scores_files/table.tex"

for ((i = 0; i < $nb_method; i++)); do
		#echo '\hline' >> $RESULTS_PATH"/scores_files/table.tex"
		line=`echo  ${array_name[$i]} | tr /a-z/ /A-Z/`' '
		
		for ((j = 0; j < 4; j++)); do
    
			scores[$(( i * 4 + j ))]=$(float_eval "${scores[$(( i * 4 + j ))]} / $nb_file")
			
			line=$line' & '${scores[$(( i * 4 + j ))]}
        
		done
	echo $line '\\' >> $RESULTS_PATH"/scores_files/table.tex"

done

echo ' 
		\end{tabular}
	\end{varwidth}
\end{document}' >> $RESULTS_PATH"/scores_files/table.tex"


cd $RESULTS_PATH/scores_files/

pdflatex $RESULTS_PATH"/scores_files/table.tex" > /dev/null
convert -density 600 "$RESULTS_PATH/scores_files/table.pdf" -quality 90 $RESULTS_PATH"/scores_files/table.png"  > /dev/null 

echo DONE
 
 
 
 
 
 
 
 
 
 
 
 
