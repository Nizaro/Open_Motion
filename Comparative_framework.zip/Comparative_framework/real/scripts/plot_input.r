#!/usr/bin/Rscript

library(tools)

## Collect arguments
args <- commandArgs(TRUE)
 
## Default setting when no arguments passed
if(length(args) > 2) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
Plot performance

Arguments:
--input=file_csv
--output=file_png  
--help

") 
 
  q(save="no")
}
 
cat("\n")

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

png(
  file      = argsL$output,
  width     = 2000,
  height    = 1200,
  units     = "px",
  res       = NA,
  pointsize = 12
)

par(
  mar      = c(5, 5, 2, 2),
  xaxs     = "i",
  yaxs     = "i",
  cex.axis = 2,
  cex.lab  = 2
)

#read csv file
csv_file <- read.csv(file=argsL$input,header=TRUE)
x_axis <- csv_file$timestamp

#get sensor value
y_axis_acc <- cbind(csv_file$xAccelerometer,csv_file$yAccelerometer,csv_file$zAccelerometer)
y_axis_gyro <- cbind(csv_file$xAngularRate,csv_file$yAngularRate,csv_file$zAngularRate)
y_axis_mag <- cbind(csv_file$xMagnetometer,csv_file$yMagnetometer,csv_file$zMagnetometer)

#for (i in 1:length(x_axis) ){
#	y_axis_mag[i,] <- y_axis_mag[i,] / sqrt(sum(y_axis_mag[i,]^2))
#}



# compute floor and ceil
min_y_axis_acc <- min(y_axis_acc)
max_y_axis_acc <- max(y_axis_acc)
ceil_y_acc <-max_y_axis_acc +  ((max_y_axis_acc - min_y_axis_acc)*0.075)
floor_y_acc <-min_y_axis_acc -  ((max_y_axis_acc - min_y_axis_acc)*0.075)

min_y_axis_gyro <- min(y_axis_gyro)
max_y_axis_gyro <- max(y_axis_gyro)
ceil_y_gyro <-max_y_axis_gyro +  ((max_y_axis_gyro - min_y_axis_gyro)*0.075)
floor_y_gyro <-min_y_axis_gyro -  ((max_y_axis_gyro - min_y_axis_gyro)*0.075)


min_y_axis_mag <- min(y_axis_mag)
max_y_axis_mag <- max(y_axis_mag)
ceil_y_mag <-max_y_axis_mag +  ((max_y_axis_mag - min_y_axis_mag)*0.075)
floor_y_mag <-min_y_axis_mag -  ((max_y_axis_mag - min_y_axis_mag)*0.075)

attach(mtcars)
par(mfrow=c(3,1)) 

matplot (x_axis, y_axis_mag, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("red","green","blue"),
	ylim = c(floor_y_mag,ceil_y_mag),
	ylab = "Magnetic intensity (in ??)",
	xlab = "Time (in minutes)",
    main = "Magnetometer"
	)
legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)


matplot (x_axis, y_axis_gyro, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("red","green","blue"),
	ylim = c(floor_y_gyro,ceil_y_gyro),
	ylab = "Angular velocity (in rad/s)",
	xlab = "Time (in minutes)",
    main = "Gyroscope"
	)
legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)

matplot (x_axis, y_axis_acc, type = "l", lty = 1, lwd = 1, pch = NULL,
     	col = c("red","green","blue"),
	ylim = c(floor_y_acc,ceil_y_acc),
	 ylab = "Acceleration (in m/s^2)",
	 xlab = "Time (in minutes)",
  	  main = "Accelerometer"
	)
legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)

dev.off()







