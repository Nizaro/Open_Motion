#!/usr/bin/Rscript

library(tools)

## Collect arguments
args <- commandArgs(TRUE)
 
## Default setting when no arguments passed
if(length(args) > 2) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
Plot performance

Arguments:
--input=file_csv
--output=file_png  
--help

") 
 
  q(save="no")
}
 
cat("\n")

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

png(
  file      = argsL$output,
  width     = 1200,
  height    = 800,
  units     = "px",
  res       = NA,
  pointsize = 12
)

par(
  mar      = c(5, 5, 2, 2),
  xaxs     = "i",
  yaxs     = "i",
  cex.axis = 2,
  cex.lab  = 2
)



#read csv file
csv_file <- read.csv(file=argsL$input,header=TRUE)
x_axis <- csv_file$index

#get sensor value
y_axis <- cbind(csv_file$quat_w,csv_file$quat_x,csv_file$quat_y,csv_file$quat_z)
y_axis_euler <- cbind(csv_file$pitch,csv_file$roll,csv_file$yaw)



# compute floor and ceil


min_y_axis <- min(y_axis)
max_y_axis <- max(y_axis)
ceil_y_mag <-max_y_axis +  ((max_y_axis - min_y_axis)*0.075)
floor_y_mag <-min_y_axis -  ((max_y_axis - min_y_axis)*0.075)


min_y_axis_euler <- min(y_axis_euler)
max_y_axis_euler <- max(y_axis_euler)
ceil_y_euler <-max_y_axis_euler +  ((max_y_axis_euler - min_y_axis_euler)*0.075)
floor_y_euler <-min_y_axis_euler -  ((max_y_axis_euler - min_y_axis_euler)*0.075)



attach(mtcars)
par(mfrow=c(2,1)) 

matplot (x_axis, y_axis, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("cyan","red","green","blue"),
	ylim = c(floor_y_mag,ceil_y_mag),
	ylab = "Quaternion Values",
	xlab = "index",
    main = "Quaternion"
	)
legend("topleft", inset=.05, legend=c("w axis","x axis","y axis","z axis"), pch=1, col = c("cyan","red","green","blue"), horiz=FALSE)


matplot (x_axis, y_axis_euler, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("red","green","blue"),
	ylim = c(floor_y_euler,ceil_y_euler),
	ylab = "Euler angle values (in rad)",
	xlab = "index",
    main = "Euler angle"
	)
legend("topleft", inset=.05, legend=c("pitch","roll","yaw"), pch=1, col = c("red","green","blue"), horiz=FALSE)

dev.off()







