/*
 * annexes.cpp
 *
 *  Created on: 25 Jan, 2017
 *      Author: thomas
 */



#include "annexes.h"

string dir_output;
string csv_imu;
string csv_vicon;



float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}



///////////////////////////////////////////////////////
/////              IO Functions                   /////
///////////////////////////////////////////////////////




void clearFile(string fileName){
	std::ofstream ofs;
	ofs.open(fileName.c_str(), std::ofstream::out | std::ofstream::trunc);
	ofs.close();
}


int getNumberLines(std::string fileName){

	 std::ifstream myfile (fileName.c_str());

	 int acc = 0;
	 std::string line;

	 if (myfile.is_open()){

		 while (std::getline(myfile , line))
			 ++acc;

		 myfile.close();
	 }
	 else cout << "Unable to open file";

	 return acc;

}

std::string remove_extension(const std::string& filename) {

	size_t lastdot = filename.find_last_of(".");
    if (lastdot == std::string::npos) return filename;
    return filename.substr(0, lastdot);

}






///////////////////////////////////////////////////////
/////              Tools Functions                /////
///////////////////////////////////////////////////////

double signeOf(double d){
	return d > 0.0 ? 1.0 : -1.0;
}


double calculQuaternionAngleDifference(omQuaternion *q_real,omQuaternion *q_est){

	double theta =0.0;
	om_quat_normalize(q_est);
	om_quat_normalize(q_real);
	double dot = om_quat_dotProduct(q_real, q_est);
	double toto = (2.0*dot*dot) - 1.0;


	int numberofdecimals = 10;


	theta = acos( toto );

	return theta*RAD_TO_DEG;

}



double calculErrorOrientation(omQuaternion *q_real,omQuaternion *q_est){

	omQuaternion q_est_inv;
	omQuaternion dq;// = q_real*q_est.inverse();
	omVector dp;

	om_vector_create(&dp,3);
	om_quat_inverse(q_est,&q_est_inv);
	om_operator_quat_mul(q_real,&q_est_inv,&dq);

	double tmp = (4.0 * (signeOf(dq._qw)))/(1.0 + fabs(dq._qw));

	om_quat_imaginary(&dq,&dp);
	om_operator_vector_scal_mul(&dp,tmp,&dp);

	return om_vector_rms(&dp);

}



std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}



std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, elems);
    return elems;
}


string tostr(const float& t) {
   ostringstream os;

   os<<std::fixed;
   os.precision(10);

   os<<t;

   return os.str();
}


float tofloat(std::string str) {
   float f = atof(str.c_str());
   return f;
}


void displayProgress(double progress){

	int barWidth = 70;

    std::cout << "[";
    int pos = barWidth * progress;
    for (int i = 0; i < barWidth; ++i) {
        if (i < pos) std::cout << "=";
        else if (i == pos) std::cout << ">";
        else std::cout << " ";
    }
    std::cout << "] " << int(progress * 100.0) << " %\r";
    std::cout.flush();



}



///////////////////////////////////////////////////////
/////              CSVReader Functions            /////
///////////////////////////////////////////////////////




CSVReader::CSVReader(){

	_file_name = "";
	_nb_columns=-1;
	_nb_rows=-1;
}

CSVReader::CSVReader(std::string file_name){

	read(file_name);
}

CSVReader::~CSVReader(){

	_columns_name.clear();

	for(unsigned int i=0;i<_columns_values.size();++i)
		_columns_values[i].clear();

	_columns_values.clear();

}



vector<std::string> CSVReader::getColumnByName(std::string column_name){

	bool find = false;

	int index=-1;

	while(!find && index < _nb_columns){
		index++;
		find = strcmp(column_name.c_str(),_columns_name[index].c_str()) == 0;
	}

	if(find){
		return _columns_values[index];
	}else{
		return vector<std::string>();
	}



}



std::string CSVReader::getCell(std::string column_name,int line){

	bool find = false;

	int index=-1;

	while(!find && index < _nb_columns){
		index++;
		find = strcmp(column_name.c_str(),_columns_name[index].c_str()) == 0;
	}

	if(find){
		return _columns_values[index][line];
	}else{
		return "null";
	}


}


void CSVReader::read(std::string file_name){

	_file_name = file_name;

	std::ifstream file(_file_name.c_str());
	std::string line;

	_nb_rows = getNumberLines(_file_name)-1;

	int row = 0;

	while (std::getline(file, line))
	{

		if(row == 0){
			_columns_name = split(line,',');
			_nb_columns= _columns_name.size();
			_columns_values = vector< vector<std::string> >(_nb_columns, vector<std::string >(_nb_rows));
		}else{


			vector<std::string> split_line = split(line,',');

				for(int i=0;i<_nb_columns;i++)
					_columns_values[i][row-1]=split_line[i];
		}

		row++;


	}

	file.close();



}
