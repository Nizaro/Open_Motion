/*
 * fast_complementary.h
 *
 *  Created on: 15 Jan 2018
 *      Author: thomas
 */

#ifndef SRC_FAST_COMPLEMENTARY_H_
#define SRC_FAST_COMPLEMENTARY_H_

#include "annexes.h"

float invSqrt_bis(float x);
void acc_mag(const float M[6], const float q_a[4], float q[4]);

void FCF_gyro_acc_mag(float *Gyroscope, float *Accelerometer, float *Magnetometer, float *q_,
	float gain_a, float gain_m, float std_norm_m, float threshold_m, float dt,float *q_est);



#endif /* SRC_FAST_COMPLEMENTARY_H_ */
