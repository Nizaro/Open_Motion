/*
 * main_validation.cpp
 *
 *  Created on: 25 Jan, 2017
 *      Author: thomas
 */

#include "fast_complementary.h"
#include <openmotion/calibration.h>

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"


typedef enum MethodType{
	MEKF,REQUEST,QUEST,USQUE,CGO,PF,GDOF,CFA,CSP,FCF
}MethodType;



typedef union Filter{


	omNonLinearFilter_CGO filter_cgo;
	omNonLinearFilter_USQUE filter_usque;
	omNonLinearFilter_CSP filter_csp;
	omNonLinearFilter_MEKF filter_mekf;
	omNonLinearFilter_REQUEST filter_request;
	omNonLinearFilter_QUEST filter_quest;
	omNonLinearFilter_PF filter_pf;
	omNonLinearFilter_GDOF filter_gdof;
	omNonLinearFilter_CFA filter_cfa;


}Filter;


typedef struct Method{

	MethodType type;
	omSensorFusionManager manager;
	Filter filter;

	vector<omQuaternion> q_est;
	vector<double> error;
	vector<double> qad;
	vector<double> time;

	std::string* name;


}Method;


typedef struct GroundTruth{

	vector<omQuaternion> q_real;
	vector<double> timestamp;


}GroundTruth;



vector<Method> methods;
GroundTruth gt;



void displayTable(int nb_method,vector<string> list_name,vector<double> list_s1,vector<double> list_s2,vector<double> list_s3,vector<double> list_s4){

    int* tab_index_best = (int*)malloc(4*sizeof(int));
    double best_s1 = 360.0;
    double best_s2 = 0.0;
    double best_s3 = 0.0;
    double best_s4 = 9999999.9;

    string file_output_name_resume = dir_output + "/fusion/resume_error/" + remove_extension(basename(strdup(csv_imu.c_str())))+"_resume.csv";
	clearFile(file_output_name_resume);

	// get file
	ofstream os_resume(file_output_name_resume.c_str(), ios::out | ios::app);

	// save error file
	if(os_resume){

		os_resume.precision(10);
		os_resume << std::fixed;

		os_resume << "method,s1,s2,s3,24" << endl;

	    for(int i=0;i<nb_method;++i){

	        double s1 = list_s1[i];
	        double s2 = list_s2[i];
	        double s3 = list_s3[i];
	        double s4 = list_s4[i];
	        string name = list_name[i];
	        os_resume << name << "," << s1 << "," <<s2 << "," << s3 <<"," << s4 << endl;

	    }

	    os_resume.close();

	}

    for(int i=0;i<nb_method;++i){

        double s1 = list_s1[i];
        double s2 = list_s2[i];
        double s3 = list_s3[i];
        double s4 = list_s4[i];

        if(best_s1 > s1){
            tab_index_best[0] = i;
            best_s1 = s1;
        }

        if(best_s2 < s2){
            tab_index_best[1] = i;
            best_s2 = s2;
        }

        if(best_s3 < s3){
            tab_index_best[2] = i;
            best_s3 = s3;
        }

        if(best_s4 > s4){
            tab_index_best[3] = i;
            best_s4 = s4;
        }


    }

    printf("+-----------+-------------+-------------+-------------+-------------+\n");
    printf("|  Method   |   score s1  |   score s2  |   score s3  |   score s4  |\n");

    for(int i=0;i<nb_method;++i){

        double s1 = list_s1[i];
        double s2 = list_s2[i];
        double s3 = list_s3[i];
        double s4 = list_s4[i];
        string name = list_name[i];



        //printf("|%9s  |  %2.7lf  |   %8.3lf  |  %2.7lf  |   %8.2lf  |\n", name, s1,s2,s3,s4);

        printf("+-----------+-------------+-------------+-------------+-------------+\n");
        printf("|%9s  ",name.c_str());

        if(i == tab_index_best[0]){
            printf("|");
            printf(KGRN "  %2.7lf  " KWHT,s1);
        }else{
            printf("|  %2.7lf  ",s1);
        }

        if(i == tab_index_best[1]){
            printf("|");
            printf(KGRN "   %8.3lf  " KWHT,s2);
        }else{
            printf("|   %8.3lf  ",s2);
        }

        if(i == tab_index_best[2]){
            printf("|");
            printf(KGRN "  %2.7lf  " KWHT,s3);
        }else{
            printf("|  %2.7lf  ",s3);
        }

        if(i == tab_index_best[3]){
            printf("|");
            printf(KGRN "   %8.2lf  " KWHT,s4);
            printf("|\n");
        }else{
            printf("|   %8.2lf  |\n",s4);
        }



    }

    printf("+-----------+-------------+-------------+-------------+-------------+\n");

    //printf("%7.1lf%11.0lf%\n", 100.1, 1221.0);
    //printf("%7.1lf%11.0lf%10.3lf\n", 2.3, 211.0, 214.0);


}


void read_args(int argc,char** argv){

	for(int i = 1; i < argc; ++i){

		if(strcmp(argv[i],"-i") == 0){
			csv_imu = std::string(argv[i+1]);
		}else if(strcmp(argv[i],"-g") == 0){
			csv_vicon = std::string(argv[i+1]);
		}else if(strcmp(argv[i],"-o") == 0){
			dir_output = std::string(argv[i+1]);
		}

	}
}


void init_ned(){

	om_vector_create(&ned_magnetic_field,3,1.0,0.0,0.0 );
	om_vector_create(&ned_magnetic_field_normalized,3);
	om_vector_clone(&ned_magnetic_field, &ned_magnetic_field_normalized);
    om_vector_normalize(&ned_magnetic_field_normalized);

    om_vector_create(&ned_gravity_normalized,3,0.0,0.0,1.0);
    om_vector_create(&ned_gravity,3,0.0,0.0,G);

}





void init_methods(int num,...){


    omEulerAngle euler;
    euler._pitch = 50.0*DEG_TO_RAD;
    euler._roll = 50.0*DEG_TO_RAD;
    euler._yaw = 50.0*DEG_TO_RAD;

	va_list arguments;
	va_start ( arguments, num );

	for ( int x = 0; x < num; x++ ){        // Loop until all numbers are added

		char* name = va_arg ( arguments, char* ); // Adds the next value in argument list to sum.

		Method method;

		method.manager.imu_params.variance_gyroscope = 0.11;
		method.manager.imu_params.variance_accelerometer = 0.000000125;
		method.manager.imu_params.variance_magnetometer = 0.000000125;
		
		om_vector_create(&method.manager.imu_params.bias_gyroscope,3,method.manager.imu_params.variance_gyroscope*0.03,method.manager.imu_params.variance_gyroscope*0.03,method.manager.imu_params.variance_gyroscope*0.03);
		om_vector_create(&method.manager.imu_params.bias_accelerometer,3,0.0,0.0,0.0);
		om_vector_create(&method.manager.imu_params.bias_magnetometer,3,0.0,0.0,0.0);

		method.manager.type = Quarternion;
        om_convert_euler2quaternion(&euler,&method.manager.output.quaternion);

        method.name = new std::string(name);

		if(strcmp(name,"usque") == 0){

			method.type = USQUE;
			method.manager.initialization_filter = &om_usque_initialization;
			method.manager.process_filter = &om_usque_process;
			method.manager.free_filter = &om_usque_free;
			method.manager.initialization_filter(&method.manager,&method.filter.filter_usque);


		}if(strcmp(name,"fcf") == 0){

			method.type = FCF;

		}else if(strcmp(name,"csp") == 0){

			method.type = CSP;
			method.manager.initialization_filter = &om_csp_initialization;
			method.manager.process_filter = &om_csp_process;
			method.manager.free_filter = &om_csp_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_csp);

		
		}



		else if(strcmp(name,"mekf") == 0){

			method.type = MEKF;
			method.manager.initialization_filter = &om_mekf_initialization;
			method.manager.process_filter = &om_mekf_process;
			method.manager.free_filter = &om_mekf_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_mekf);



		}else if(strcmp(name,"quest") == 0){

			method.type = QUEST;
			method.manager.initialization_filter = &om_quest_initialization;
			method.manager.process_filter = &om_quest_process;
			method.manager.free_filter = &om_quest_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_quest);

		}
		else if(strcmp(name,"cgo") == 0){

			method.type = CGO;
			method.manager.initialization_filter = &om_cgo_initialization;
			method.manager.process_filter = &om_cgo_process;
			method.manager.free_filter = &om_cgo_free;
			method.manager.initialization_filter(&method.manager,&method.filter.filter_cgo);



		}else if(strcmp(name,"request") == 0){

			method.type = REQUEST;
			method.manager.initialization_filter = &om_request_initialization;
			method.manager.process_filter = &om_request_process;
			method.manager.free_filter = &om_request_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_request);

		}

		else if(strcmp(name,"pf") == 0){

			method.type = PF;
			method.manager.initialization_filter = &om_pf_initialization;
			method.manager.process_filter = &om_pf_process;
			method.manager.free_filter = &om_pf_free;

			//*/
			om_vector_setValues(&method.manager.imu_params.bias_gyroscope,3,0.00031623,0.00031623,0.00031623);
			method.manager.imu_params.variance_gyroscope = 0.11;
			method.manager.imu_params.variance_accelerometer = 0.0075;
			method.manager.imu_params.variance_magnetometer = 0.0075;
			//*/
			method.manager.initialization_filter(&method.manager,&method.filter.filter_pf);

		}
		else if(strcmp(name,"gdof") == 0){

			method.type = GDOF;
			method.manager.initialization_filter = &om_gdof_initialization;
			method.manager.process_filter = &om_gdof_process;
			method.manager.free_filter = &om_gdof_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_gdof);

		}	else if(strcmp(name,"cfa") == 0){

			method.type = CFA;
			method.manager.initialization_filter = &om_cfa_initialization;
			method.manager.process_filter = &om_cfa_process;
			method.manager.free_filter = &om_cfa_free;

			method.manager.initialization_filter(&method.manager,&method.filter.filter_cfa);

		}



		methods.push_back(method);

	}

}



void free_methods(int nb_method){

	for(int l=0;l<nb_method;l++){
    	switch(methods[l].type){

    		case USQUE:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_usque);
    			break;

    		case CSP:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_csp);
    			break;

    		case MEKF:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_mekf);
    			break;

    		case CGO:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_cgo);
    			break;

    		case REQUEST:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_request);
    			break;

    		case QUEST:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_quest);
    			break;


    		case PF:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_pf);
    			break;

    		case GDOF:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_gdof);
    			break;

    		case CFA:
    			methods[l].manager.free_filter((void*)&methods[l].filter.filter_cfa);
    			break;


    		default:

    			break;

    	}

	}

}


void load_gt(){

	std::ifstream file_vicon(csv_vicon.c_str());
	std::string line;

	string file_output_name = dir_output + "/base_files/gt/" + remove_extension(basename(strdup(csv_imu.c_str())))+"_gt.csv";

	clearFile(file_output_name);


	/* get file */

	ofstream os_quat(file_output_name.c_str(), ios::out | ios::app);

	cout << csv_vicon<< endl;

	// save error file
	if(os_quat){

		os_quat.precision(10);
		os_quat << std::fixed;

		os_quat << "index,quat_w,quat_x,quat_y,quat_z,pitch,roll,yaw\n";
		int index = 0;



		while (std::getline(file_vicon, line) )
		{
			vector<std::string> split_line = split(line,',');

			if(split_line[0].compare("timestamp") != 0){
				gt.timestamp.push_back(atof(split_line[0].c_str()));

				omEulerAngle ea;
				ea._roll = atof(split_line[4].c_str());
				ea._pitch = atof(split_line[5].c_str());
				ea._yaw = atof(split_line[6].c_str());

				omQuaternion q_real;
				om_convert_euler2quaternion(&ea,&q_real);
				gt.q_real.push_back(q_real);

		    	//printf("q_real = ");
		    	//om_quat_display(&q_real);
				//printf("timestamp = %f q_real = ",tofloat(split_line[0]));
				//om_quat_display(&q_real);

				/*/
				 q_real._qw =  q_real._qw * signeOf( q_real._qw);
				 q_real._qx =  q_real._qx * signeOf( q_real._qw);
				 q_real._qy =  q_real._qy * signeOf( q_real._qw);
				 q_real._qz =  q_real._qz * signeOf( q_real._qw);
				//*/
				os_quat << index << "," << q_real._qw << "," << q_real._qx << "," << q_real._qy << "," << q_real._qz  << "," << ea._pitch<< "," << ea._roll<< "," << ea._yaw<< "\n";

				index++;
			}

		}


	}

}







void save_results(int nb_method){

	vector<string> list_name;
	vector<double> list_s1;
	vector<double> list_s2;
	vector<double> list_s3;
	vector<double> list_s4;


	for(int j=0;j<nb_method;++j){

		string file_output_name_error = dir_output + "/base_files/error/" + remove_extension(basename(strdup(csv_imu.c_str())))+"_"+ (*methods[j].name)+".csv";
		string file_output_name_quat = dir_output + "/base_files/attitude/" + remove_extension(basename(strdup(csv_imu.c_str())))+"_"+ (*methods[j].name)+".csv";


		clearFile(file_output_name_error);
		clearFile(file_output_name_quat);


		/* get file */
		ofstream os_error(file_output_name_error.c_str(), ios::out | ios::app);
		ofstream os_quat(file_output_name_quat.c_str(), ios::out | ios::app);



		// save error file
		if(os_error && os_quat){

			os_error.precision(10);
			os_error << std::fixed;

			os_quat.precision(10);
			os_quat << std::fixed;


			double mean_qad = 0.0;
	        double mean_error = 0.0;
	        double mean_time = 0.0;
	        double mean_lambda = 0.0;
	        double s4 = 0.0;
	        double T_i = 0.0;
	        double e_0 = 0.0;
	        double old_error = 0.0;

	        int n = 300;


			os_error << "index,time,error,qad \n";
			os_quat << "index,quat_w,quat_x,quat_y,quat_z,pitch,roll,yaw\n";

			for(unsigned int i=0;i<methods[j].error.size();++i){
				omEulerAngle ea;
				om_convert_quaternion2euler(&methods[j].q_est[i],&ea);

				double error = methods[j].error[i];

				os_error << i << "," << methods[j].time[i] << "," << methods[j].error[i] <<"," << methods[j].qad[i] << "\n";
				os_quat << i << "," << methods[j].q_est[i]._qw << "," << methods[j].q_est[i]._qx << "," << methods[j].q_est[i]._qy << "," << methods[j].q_est[i]._qz << "," << ea._pitch<< "," << ea._roll<< "," << ea._yaw<< "\n";



                if(i>0 && i<n){
                    mean_lambda += ((-1.0)/(T_i))*log( error / e_0 );

                    double diff = fabs(error - old_error);
                    old_error = error;

                    if(i > 2000){
                    	s4 += diff < 0.0 ? (diff*(-1.0)) : diff;
                    }

                }else if(i>0){

                    double diff = fabs(error - old_error);
                    old_error = error;

                    if(i > 2000){
                    	s4 += diff < 0.0 ? (diff*(-1.0)) : diff;
                    }



                }else{

                    e_0 = error;
                    old_error = error;
                }

                T_i += DELTA_T;
                mean_error += error;
                mean_qad += methods[j].qad[i];
                mean_time += methods[j].time[i];


			}


			mean_qad /= (double)(methods[j].qad.size());
            mean_error /= (double)(methods[j].error.size());
            mean_time /= (double)(methods[j].time.size());
            mean_lambda /= (double)(n);

            double s2 = 1.0/(mean_time*mean_error*10000.0);

            list_name.push_back((*methods[j].name));
            list_s1.push_back(mean_qad);
            list_s2.push_back(s2);
            list_s3.push_back(1.0/mean_lambda);
            list_s4.push_back(s4);

			//cout << (*methods[j].name) <<" mean_error = " <<mean_error/static_cast<double>(methods[j].error.size()) << endl;

			os_error.close();
			os_quat.close();

		}else
			cerr << "ERROR Opening file result csv " << file_output_name_error << endl;




	}


	displayTable(nb_method,list_name,list_s1,list_s2,list_s3,list_s4);


}


void load_mag_field(){

	std::ifstream file_imu(csv_imu.c_str());
	std::string line;

	int index_vicon = 0;
	int total_vicon = getNumberLines(csv_imu)-1;

	omVector sum;
	om_vector_create(&sum,3,0.0,0.0,0.0);

	while (std::getline(file_imu, line) )
	{

		vector<std::string> split_line = split(line,',');

		if(split_line[0].compare("timestamp") != 0){


			double timestamp = atof(split_line[0].c_str());
			double mag_x = atof(split_line[10].c_str()),mag_y = atof(split_line[11].c_str()),mag_z = atof(split_line[12].c_str());

			double diff = (timestamp - gt.timestamp[index_vicon]);
			diff = diff > 0.0 ? diff : diff*(-1.0);

	    	if(index_vicon < total_vicon && diff < 1.0){

	    		omVector mag;
	    		omVector ned_mag;
	    		omQuaternion q_inv;

	    		om_vector_create(&mag,3,mag_x,mag_y,mag_z);
	    		om_vector_create(&ned_mag,3);
	    		om_quat_inverse(&gt.q_real[index_vicon],&q_inv);

	    		om_rotate_vector_quaternion(&q_inv,&mag,&ned_mag);
	    		om_operator_vector_add(&sum,&ned_mag,&sum);

	    		index_vicon++;

	    		om_vector_free(&mag);
	    		om_vector_free(&ned_mag);
	    	}


		}

	}


	om_operator_vector_scal_div(&sum,(double)(index_vicon),&sum);
	//om_vector_normalize(&sum);

	printf("mean mag = ");
	om_vector_display(&sum);

	om_vector_clone(&sum,&ned_magnetic_field);
	om_vector_clone(&sum,&ned_magnetic_field_normalized);
	om_vector_normalize(&ned_magnetic_field_normalized);

}

void process(int nb_method){


	std::ifstream file_imu(csv_imu.c_str());
	std::string line;

	int index_vicon = 0;
	int index_imu = 0;

	int total_imu = getNumberLines(csv_imu)-1;
	int total_vicon = getNumberLines(csv_imu)-1;

	double old_timestamp = -1.0;

	for(int l=0;l<nb_method;l++){
    	om_vector_create(&methods[l].manager.imu_data.data_accelerometer,3,0.0,0.0,0.0);
    	om_vector_create(&methods[l].manager.imu_data.data_magnetometer,3,0.0,0.0,0.0);
    	om_vector_create(&methods[l].manager.imu_data.data_gyroscope,3,0.0,0.0,0.0);
	}


	/*/
    int dwell_time_cgo = (int)(1.0 / DELTA_T);
    int bool_switch_cgo = 0;
    int acc_cgo = 0;
    //*/

	////////
	// FCF Stuff
	////////


	float acc[3], gyro[3], mag[3], euler_true[3],time,dt,last_q[4],q_est[4];

	q_est[0] = 1.0f;
	q_est[1] = 0.0f;
	q_est[2] = 0.0f;
	q_est[3] = 0.0f;

	last_q[0] = 1.0f;
	last_q[1] = 0.0f;
	last_q[2] = 0.0f;
	last_q[3] = 0.0f;


	omQuaternion tmp_dq;
	om_quat_create(&tmp_dq,0.6008,-0.0010,0.0177,-0.7960);



	omVector angular;
	omVector gravity;
	omVector field;
	om_vector_create(&angular, 3,0.0,0.0,0.0);
	om_vector_create(&gravity, 3,0.0,0.0,0.0);
	om_vector_create(&field, 3,0.0,0.0,0.0);

	double alpha_acc = 0.5;
	double alpha_gyro = 0.5;
	double alpha_mag = 0.5;


	while (std::getline(file_imu, line) )
	{


		vector<std::string> split_line = split(line,',');

		if(split_line[0].compare("timestamp") != 0){


			double timestamp = atof(split_line[0].c_str());

			double acc_x = atof(split_line[1].c_str()),acc_y = atof(split_line[2].c_str()),acc_z = atof(split_line[3].c_str());
			double gyro_x = atof(split_line[4].c_str()),gyro_y = atof(split_line[5].c_str()),gyro_z = atof(split_line[6].c_str());
			double mag_x = atof(split_line[10].c_str()),mag_y = atof(split_line[11].c_str()),mag_z = atof(split_line[12].c_str());
			old_timestamp = timestamp;

			/////////
	    	// gyro filter
	    	////////

	    	omVector gyro_tmp;
	    	om_vector_create(&gyro_tmp,3,gyro_x,gyro_y,gyro_z);

	    	for(int h=0;h<3;++h){
	    		double toto = (alpha_gyro * om_vector_getValue(&angular,h)) + ((1.0 - alpha_gyro)*om_vector_getValue(&gyro_tmp,h));
	    		om_vector_setValue(&gyro_tmp, h, toto);
	    		om_vector_setValue(&angular, h, toto);
	    	}


	    	/////////
	    	// acc filter
	    	////////
	    	omVector acc_tmp;
	    	om_vector_create(&acc_tmp,3,acc_x,acc_y,acc_z);
	    	om_operator_vector_scal_mul(&acc_tmp, -1.0, &acc_tmp);

	    	for(int h=0;h<3;++h){
	    		double toto = (alpha_acc * om_vector_getValue(&gravity,h)) + ((1.0 - alpha_acc)*om_vector_getValue(&acc_tmp,h));
	    		om_vector_setValue(&acc_tmp, h, toto);
	    		om_vector_setValue(&gravity, h, toto);
	    	}

	    	/////////
	    	// mag filter
	    	////////
	    	omVector mag_calib;
	    	om_vector_create(&mag_calib,3,mag_x,mag_y,mag_z);

	    	for(int h=0;h<3;++h){
	    		double toto = (alpha_mag * om_vector_getValue(&field,h)) + ((1.0 - alpha_mag)*om_vector_getValue(&mag_calib,h));
	    		om_vector_setValue(&mag_calib, h, toto);
	    		om_vector_setValue(&field, h, toto);
	    	}


			//for all methods
			for(int l=0;l<nb_method;l++){

				// set data
	    		om_vector_clone(&gyro_tmp, &methods[l].manager.imu_data.data_gyroscope);
	    		om_vector_clone(&acc_tmp, &methods[l].manager.imu_data.data_accelerometer);
	    		om_vector_clone(&mag_calib, &methods[l].manager.imu_data.data_magnetometer);
	    		om_operator_vector_scal_mul(&methods[l].manager.imu_data.data_accelerometer,G,&methods[l].manager.imu_data.data_accelerometer);

	    		// Variables
		    	double texec=0.0;
		    	struct timeval tbegin,tend;

		    	// Start timer
		    	gettimeofday(&tbegin,NULL);


		    	switch(methods[l].type){

					case FCF:

						gyro[0] = om_vector_getValue(&methods[l].manager.imu_data.data_gyroscope, 0);
						gyro[1] = om_vector_getValue(&methods[l].manager.imu_data.data_gyroscope, 1);
						gyro[2] = om_vector_getValue(&methods[l].manager.imu_data.data_gyroscope, 2);

						acc[0] = om_vector_getValue(&methods[l].manager.imu_data.data_accelerometer, 0)/G;
						acc[1] = om_vector_getValue(&methods[l].manager.imu_data.data_accelerometer, 1)/G;
						acc[2] = om_vector_getValue(&methods[l].manager.imu_data.data_accelerometer, 2)/G;

						mag[0] = om_vector_getValue(&methods[l].manager.imu_data.data_magnetometer, 0);
						mag[1] = om_vector_getValue(&methods[l].manager.imu_data.data_magnetometer, 1);
						mag[2] = om_vector_getValue(&methods[l].manager.imu_data.data_magnetometer, 2);


						//0.005f, 0.01f
						FCF_gyro_acc_mag(gyro, acc, mag, last_q, 0.35f, 0.35f, (float)om_vector_norm(&ned_magnetic_field), 1000.0f, DELTA_T, q_est);
						//FCF_gyro_acc_mag(gyro, acc, mag, last_q, 0.005f, 0.01f, (float)om_vector_norm(&ned_magnetic_field), 1000.0f, DELTA_T, q_est);

						last_q[0] = q_est[0];
						last_q[1] = q_est[1];
						last_q[2] = q_est[2];
						last_q[3] = q_est[3];


						om_quat_create(&methods[l].manager.output.quaternion,q_est[0],q_est[1],q_est[2],q_est[3]);
						om_operator_quat_mul(&methods[l].manager.output.quaternion, &tmp_dq, &methods[l].manager.output.quaternion);

						break;

		    		case USQUE:

		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_usque);

		    			break;

		    		case MEKF:
		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_mekf);
		    			break;

		    		case CSP:
		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_csp);
		    			break;


		    		case CGO:
						methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_cgo);

		    			break;

		    		case REQUEST:

		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_request);
		    			break;

		    		case QUEST:

		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_quest);
		    			break;
		    		case PF:
		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_pf);
		    			break;

		    			break;
		    		case GDOF:
							methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_gdof);
							om_operator_quat_mul(&methods[l].manager.output.quaternion, &tmp_dq, &methods[l].manager.output.quaternion);
		    			break;

		    		case CFA:
		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_cfa);
		    			break;


		    		default:
		    			methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_usque);
		    			break;

		    	}

		    	gettimeofday(&tend,NULL);

		    	// Compute execution time
		    	texec=((double)(1000.0*(tend.tv_sec-tbegin.tv_sec)+((tend.tv_usec-tbegin.tv_usec)/1000.0)))/1000.0;
		    	methods[l].time.push_back(texec);


			}// end for loop over methods

			double diff = fabs(timestamp - gt.timestamp[index_vicon]);

	    	if(index_vicon < total_vicon && diff < 0.001 ){

	    		for(int l=0;l<nb_method;l++){

	    			omQuaternion q_est;

	    			q_est._qw = methods[l].manager.output.quaternion._qw;
	    			q_est._qx = methods[l].manager.output.quaternion._qx;
	    			q_est._qy = methods[l].manager.output.quaternion._qy;
	    			q_est._qz = methods[l].manager.output.quaternion._qz;

	    			double error = calculErrorOrientation(&methods[l].manager.output.quaternion,&gt.q_real[index_vicon]);
	    			double qad = calculQuaternionAngleDifference(&methods[l].manager.output.quaternion,&gt.q_real[index_vicon]);

					methods[l].qad.push_back(qad);
					methods[l].error.push_back(error);
					methods[l].q_est.push_back(q_est);



		    		/*/
		    		cout << "\nmethod "<< (*methods[l].name) ;
			    	printf(" error = %f\n",error);
			    	printf("q_true = ");
			    	om_quat_display(&gt.q_real[index_vicon]);
			    	printf("q_est = ");
			    	om_quat_display(&methods[l].manager.output.quaternion);
					printf("\n");

			    	if(isnan(error)){
			    		exit(1);
			    	}
		    		//*/
	    		}



	    		index_vicon++;

	    	}
		}// end if(split_line[0].compare("timestamp"))

		index_imu++;
		displayProgress((double)(index_imu)/(double)(total_imu));
	}//end while (std::getline(file_imu, line) )



	save_results(nb_method);

}


int main(int argc,char** argv){


	DELTA_T = 0.005;
	read_args(argc,argv);

	load_gt();

	init_ned();
	load_mag_field();

	int nb_method = 2;
	init_methods(nb_method,"fcf","csp","gdof","usque","mekf","cgo","quest","cfa","request","pf");
	process(nb_method);


	return EXIT_SUCCESS;
}








