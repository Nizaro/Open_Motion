/*
 * annexes.h
 *
 *  Created on: 25 Jan, 2017
 *      Author: thomas
 */

#ifndef SRC_ANNEXES_H_
#define SRC_ANNEXES_H_


#ifdef __cplusplus
extern "C"{
#endif

#include <openmotion/om.h>

#ifdef __cplusplus
}
#endif

#include <unistd.h>
#include <math.h>      // For math routines (such as sqrt & trig).
#include <stdio.h>
#include <stdlib.h>      // For the "exit" function
#include <iomanip>
#include <string.h>
#include <string>
#include <vector>
#include <cstdio>
#include <deque>
#include <cstdlib>
#include <stdarg.h>
#include <algorithm>
#include <cmath>
#include <libgen.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <typeinfo>

using namespace std;


extern string dir_output;
extern string csv_imu;
extern string csv_vicon;


void clearFile(string fileName);
std::vector<std::string> split(const std::string &s, char delim);
float tofloat(std::string str);
string tostr(const float& t);
int getNumberLines(std::string fileName);
std::string remove_extension(const std::string& filename);
void displayProgress(double progress);
double signeOf(double d);
double calculErrorOrientation(omQuaternion *q_real,omQuaternion *q_est);
double calculQuaternionAngleDifference(omQuaternion *q_real,omQuaternion *q_est);






float invSqrt(float x);

template <typename T> string NumberToString ( T Number );
template <int> string NumberToString ( int Number );




class CSVReader{

public:
	CSVReader();
	CSVReader(std::string file_name);
	~CSVReader();

	void read(std::string file_name);


	int getColums(){return _nb_columns;}
	int getRows(){return _nb_rows;}

	vector<std::string> getColumnNames () { return _columns_name ;}
	vector<std::string> getColumn (unsigned int i) { return _columns_values[i] ;}
	vector<std::string> getColumnByName (std::string column_name);

	std::string getCell(std::string column_name,int line);


private:
	std::string _file_name;
	vector<std::string> _columns_name;
	vector< vector<std::string> > _columns_values;

	int _nb_columns;
	int _nb_rows;
};







#endif /* SRC_ANNEXES_H_ */
