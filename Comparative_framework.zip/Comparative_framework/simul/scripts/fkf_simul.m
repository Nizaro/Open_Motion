format long

addpath('../../FKF');
addpath('../../FKF/quaternion_library');
addpath('../../FKF/linspecer');

tmp_files = dir(fullfile('../data_set/csv', '*.csv'));

acc=1;
files = strings(size(tmp_files,1),1);
for nf=1:size(tmp_files,1)
    %{
    index = strfind(tmp_files(nf).name,'strong');
    
    if size(index,1)>0
       files(acc,1) = tmp_files(nf).name;
       acc = acc+1;
    end
  %}
    files(nf,1) = tmp_files(nf).name;
end


nb_file = size(files,1);
nb_file = 1;

%dir_name = '/home/thomas/These/NEW_STUFF/Comparative_framework/simul/results/toto';

%for each file
scores = zeros(nb_file,5);
for nf = 1:nb_file
    %printf('start for : %s\n',strcat(' ',char(files(nf))));
    
    %file_input_name = '/home/thomas/These/NEW_STUFF/Comparative_framework/simul/data_set/csv/test2_add_moderate_constant.csv';
    file_input_name = strcat('../data_set/csv/',files(nf));
   
    csv_data = csvread(file_input_name,1,0); 
    
    quaternion_true=csv_data(:,5:8);
    data_Gyro=csv_data(:,[9,10,11]);
    data_Acc=csv_data(:,[12,13,14]);
    data_Mag=csv_data(:,[15,16,17]);

    eul=[0.872664626,0.872664626,0.872664626];
    init_quat=eul2quat(eul);
    q=init_quat';

    dt=0.02;
    len=length(csv_data(:,1));
    time=dt*(1:len);

    quaternion=zeros(len,4);
    quaternion_measurement=zeros(len,4);
    STD=zeros(len,4);
    
    %var_accel=0.05;
    %var_magn=0.015;
    %var_gyro=0.00031623;

    var_accel=0.01;
    var_magn=0.01;
    var_gyro=0.001;

    
    bias_accel=[0,0,0];
    bias_magn=[0,0,0];
    bias_gyro=[0.000031623,0.0000316230,0.00003162];

    Sigma_g=var_gyro*eye(3);
    Sigma_a=var_accel*eye(3);
    Sigma_m=var_magn*eye(3);
    Pk=0.001*eye(4);
    
    %% FKF PROCESS
    fkf_time = zeros(len-1,1);
    for i=1:len
        tic;
        q0=q(1);
        q1=q(2);
        q2=q(3);
        q3=q(4);

        wx=data_Gyro(i,1);
        wy=data_Gyro(i,2);
        wz=data_Gyro(i,3);

        data_Acc(i,:)=data_Acc(i,:)./norm(data_Acc(i,:));
        data_Mag(i,:)=data_Mag(i,:)./norm(data_Mag(i,:));

        mD=data_Acc(i,:)*data_Mag(i,:)';
        mN=sqrt(1-mD^2);

        omega4=[0,-wx,-wy,-wz;
            wx,0,wz,-wy;
            wy,-wz,0,wx;
            wz,wy,-wx,0];

        Phi=eye(4)+dt/2*omega4;

        Dk=[q1 q2 q3;
            -q0 -q3 -q2;
            q2 -q0 -q1;
            -q2 q1 -q0];
        Xi=dt*dt/4*Dk*Sigma_g*Dk';

        [qy, Jacob]=measurement_quaternion_acc_mag(data_Acc(i,:),data_Mag(i,:),[mN,0,mD], q);
        qy=qy./norm(qy);

        Eps=Jacob*[Sigma_a,zeros(3,3);zeros(3,3),Sigma_m]*Jacob';

        std=sqrt([Eps(1,1),Eps(2,2),Eps(3,3),Eps(4,4)]);

        q_=q;
        Pk_ = Pk;
        [q , Pk] = kalman_update(q_, qy, Pk_, Phi, Xi, Eps);


        q=q./norm(q);
        quaternion(i,:)=q';
        quaternion_measurement(i,:)=qy';
        STD(i,:)=std;
       
        toc;
        elapsedTime = toc;
        
        if(i<len)
            fkf_time(i) = elapsedTime;
        end
    end

    
     % QAD
     fkf_theta = zeros(len-1,1);
     for i=2:len
        q_true = quaternion_true(i,1:4)'/norm(quaternion_true(i,1:4));
        fkf_q_est  = quaternion(i,1:4)/norm(quaternion(i,1:4));

        dot = q_true'*fkf_q_est';
        darth = ((2.0*dot*dot) - 1.0);
          if darth > 1.0 
              
            darth = 2.0 - darth;
          end
        fkf_theta(i-1) = acosd( darth );
     end

     % MAE
     fkf_error = zeros(len-1,1);
     for i=2:len
        q_true = quaternion_true(i,:);
        fkf_q_est  = quaternion(i,:);

        for j=2:4
            fkf_q_est(j)=fkf_q_est(j)*-1;
        end

        fkf_dq = quatmultiply(q_true,fkf_q_est);
        fkf_dp = zeros(1,3);

       for j=1:3
            fkf_dp(j)=fkf_dq(j+1);

       end

       if fkf_dq(1) < 0.0
           tmp = -4.0/(1.0 + abs(fkf_dq(1)));
       else
           tmp = 4.0/(1.0 + abs(fkf_dq(1)));
       end

       fkf_dp = fkf_dp*tmp;
       fkf_error(i-1) = rms(fkf_dp);
     end

   
    
    [filepath,name,ext] = fileparts(char(file_input_name));
    file_output= sprintf('%s/base_files/error/%s_fkf.csv',dir_name,name);
    
    
    csvexport=zeros(len-1,4);
    
    csvexport(:,1)=(0:len-2);
    csvexport(:,2)=fkf_time(:);
    csvexport(:,3)=fkf_error(:);
    csvexport(:,4)=fkf_theta(:);
    csvwrite(file_output,csvexport)
    
    S = fileread(file_output);
    S = ['index,time,error,qad', char(10), S];
    FID = fopen(file_output, 'w');
    if FID == -1, error('Cannot open file %s', file_output); end
    fwrite(FID, S, 'char');
    fclose(FID);
    
    
end



