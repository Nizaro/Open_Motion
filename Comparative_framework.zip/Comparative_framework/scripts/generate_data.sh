#!/bin/bash

echo DATA GENERATOR


####################
# MATHS FUNCTIONS  #
####################

float_scale=5

function float_eval()
{
    local stat=0
    local result=0.0
    if [[ $# -gt 0 ]]; then
        result=$(echo "scale=$float_scale; $*" | bc -q 2>/dev/null)
        stat=$?
        if [[ $stat -eq 0  &&  -z "$result" ]]; then stat=1; fi
    fi
    echo $result
    return $stat
}

function float_cond()
{
    local cond=0
    if [[ $# -gt 0 ]]; then
        cond=$(echo "$*" | bc -q 2>/dev/null)
        if [[ -z "$cond" ]]; then cond=0; fi
        if [[ "$cond" != 0  &&  "$cond" != 1 ]]; then cond=0; fi
    fi
    local stat=$((cond == 0))
    return $stat
}




#get current directory
cd ../
ROOT_DIR=`pwd`


if [ ! -d "$ROOT_DIR/bin" ]; then

	mkdir bin
	cd $ROOT_DIR/src

	echo  Compilation source file... 

	make

	mv performance_evaluation ../bin
	mv sensor_simulator ../bin

	echo DONE
else

	cd $ROOT_DIR/src

	echo -neCompilation source file... 

	make

	mv performance_evaluation ../bin
	mv sensor_simulator ../bin

	echo DONE

fi





if [  "$(ls -A $ROOT_DIR/data_set/csv/)" ]; then
	rm $ROOT_DIR/data_set/csv/*.csv
fi


if [  "$(ls -A $ROOT_DIR/data_set/png/)" ]; then
	rm $ROOT_DIR/data_set/png/*.png
fi

cd $ROOT_DIR

####################
# TOTAL SIMULATION #
####################

N=50

for i in "$@"
do
case $i in 
	*-n*) N=$2;;
	*) ;;

esac
done


seed_x=0
seed_y=10000
seed_z=20000

#################
# ROTATION AXIS #
#################
rot_x=0.0
rot_y=0.0
rot_z=0.0


#run simulator monte carlo style bitch :) 
for (( i=1; i<=$N; i++ ))
do

	#axis definition
	num=""
	case $i in
	
		#generate random rotation axis 
		*) num=`echo $i`
		   rot_x=`python $ROOT_DIR/scripts/random_generator.py --seed $seed_x`
	 	   rot_y=`python $ROOT_DIR/scripts/random_generator.py --seed $seed_y`
           rot_z=`python $ROOT_DIR/scripts/random_generator.py --seed $seed_z`;;

	esac
	
	seed_x=$(( seed_x + 1 ))
	seed_y=$(( seed_y + 1 ))
	seed_z=$(( seed_z + 1 ))
	
	#run simulator with different strenght of noise
	for j in {1..3};do

			#type definition			
			case $j in
				1) noise_strength="weak" ;;
				2) noise_strength="moderate" ;;
				3) noise_strength="strong" ;;
			esac


		for k in {1..2};do

			#type definition			
			case $k in
				1) noise_type="add" ;;
				2) noise_type="imp" ;;
			esac
		
			for l in {1..3};do

				#rotation pattern definition			
				case $l in
					1) pattern="constant" ;;
					2) pattern="echelon" ;;
					3) pattern="sinus" ;;
				esac
		
				echo -ne Generate simulation num=$num  with Axe=[$rot_x,$rot_y,$rot_z] strength=$noise_strength type=$noise_type pattern=$pattern... '\b'
			
				#start simulation
				$ROOT_DIR/bin/sensor_simulator -n $i -d $ROOT_DIR/data_set/csv/ -nt $noise_type -p $pattern -ns $noise_strength --axis $rot_x $rot_y $rot_z --angle 0.015
				
				echo DONE
			
			done

	
		done
	done



done



echo -ne Plotting sensor data... '\b'
for data in $( ls $ROOT_DIR/data_set/csv/*.csv ); do
	
	#get absolute path
	real_path=`readlink -m $data`

	tmp=`echo "$data" | rev | cut -d'/' -f1 | rev`			
	name_output=`echo "$tmp" | cut -d'.' -f1`
	case $real_path in
		*test1_*) $ROOT_DIR/scripts/plot_input.r --input=$real_path --output="$ROOT_DIR/data_set/png/$name_output.png" > /dev/null ;;
	esac
	
done
echo DONE

echo END SCRIPT



