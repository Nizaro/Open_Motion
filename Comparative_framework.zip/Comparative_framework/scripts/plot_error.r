#!/usr/bin/Rscript

suppressMessages(library(limma))

## Collect arguments
args <- commandArgs(TRUE)
 

 
## Default setting when no arguments passed
if(length(args) < 1) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
      The R Script
 
      Arguments:
      --nb_method=n
	  --input=file_csv
	  --output=file_png  
      --method_name=c(name1,name2)
      --column_name=c(name1,name2)
      --help") 
 
  q(save="no")
}
 
cat("\n")

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

output_file=argsL$output
input_file=argsL$input
method_name <- unlist(strsplit(argsL$method_name, "[,]"))
column_name <- unlist(strsplit(argsL$column_name, "[,]"))
nb_method=argsL$nb_method



png(
  file      = output_file,
  width     = 800,
  height    = 600,
  units     = "px",
  res       = NA,
  pointsize = 12
)

par(
  mar      = c(5, 5, 2, 2),
  xaxs     = "i",
  yaxs     = "i",
  cex.axis = 2,
  cex.lab  = 2
)


csv_file <- read.csv(input_file,header=TRUE)
x_axis <- csv_file$index
x_axis <- x_axis * 0.001

for (i in 1:nb_method ) {

		
	if( i == 1 ){
		y_axis <- read.columns(input_file, column_name[i], sep = ",")
	}else{
		y_axis <- cbind(read.columns(input_file, column_name[i], sep = ","),y_axis)
	}
}

#col = c("blue","green","red","magenta","cyan"),
#col = c("cyan","magenta","red","green","blue")

matplot (x_axis, y_axis, type = "l", lty = 1, lwd = 2, pch = NULL,
         col = c("blue","green","red","gray","yellow","brown","magenta","cyan","black"),
		 xlab = 	"Samples",
		 ylab = "RMS Attitude Error",
		 log="y",
		 main = argsL$file_name 
	)

legend("topright", inset=.05, legend=method_name, pch=1, col = c("black","cyan","magenta","brown","yellow","gray","red","green","blue"), horiz=FALSE, cex=1.55)






dev.off()





























