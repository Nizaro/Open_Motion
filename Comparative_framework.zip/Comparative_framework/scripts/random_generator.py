import random
import sys, getopt

def main(argv):
   seed = 0
   try:
      opts, args = getopt.getopt(argv,"s:",["seed="])
   except getopt.GetoptError:
      print 'random_generator.py -s <seed>'
      sys.exit(2)

   for opt, arg in opts:
      if opt in ("-s", "--seed"):
        seed = arg
	random.seed(seed)  
	print '%04.3f' % random.random()

if __name__ == "__main__":
   main(sys.argv[1:])
