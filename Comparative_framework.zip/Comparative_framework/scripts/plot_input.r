#!/usr/bin/Rscript

library(tools)

## Collect arguments
args <- commandArgs(TRUE)
 
## Default setting when no arguments passed
if(length(args) > 2) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
Plot performance

Arguments:
--input=file_csv
--output=file_png  
--help

") 
 
  q(save="no")
}
 
cat("\n")

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

png(
  file      = argsL$output,
  width     = 2000,
  height    = 1200,
  units     = "px",
  res       = NA,
  pointsize = 12
)

par(
  mar      = c(5, 5, 2, 2),
  xaxs     = "i",
  yaxs     = "i",
  cex.axis = 2,
  cex.lab  = 2
)

#read csv file
csv_file <- read.csv(file=argsL$input,header=TRUE)
x_axis <- csv_file$time

#get sensor value
y_axis_heading <- cbind(csv_file$simulMagX,csv_file$simulMagY,csv_file$simulMagZ)
y_axis_acc <- cbind(csv_file$simulAccX,csv_file$simulAccY,csv_file$simulAccZ)
y_axis_gyro <- cbind(csv_file$simulGyroX,csv_file$simulGyroY,csv_file$simulGyroZ)

#normalize mag
for (i in 1:length(x_axis) ) {
	y_axis_heading[i,] = y_axis_heading[i,]/norm(t(t(y_axis_heading[i,])))
}

# compute floor and ceil
min_y_axis_heading <- min(y_axis_heading)
max_y_axis_heading <- max(y_axis_heading)
ceil_y_heading <-max_y_axis_heading +  ((max_y_axis_heading - min_y_axis_heading)*0.075)
floor_y_heading <-min_y_axis_heading -  ((max_y_axis_heading - min_y_axis_heading)*0.075)

min_y_axis_acc <- min(y_axis_acc)
max_y_axis_acc <- max(y_axis_acc)
ceil_y_acc <-max_y_axis_acc +  ((max_y_axis_acc - min_y_axis_acc)*0.075)
floor_y_acc <-min_y_axis_acc -  ((max_y_axis_acc - min_y_axis_acc)*0.075)

min_y_axis_gyro <- min(y_axis_gyro)
max_y_axis_gyro <- max(y_axis_gyro)
ceil_y_gyro <-max_y_axis_gyro +  ((max_y_axis_gyro - min_y_axis_gyro)*0.075)
floor_y_gyro <-min_y_axis_gyro -  ((max_y_axis_gyro - min_y_axis_gyro)*0.075)


attach(mtcars)
par(mfrow=c(3,1)) 


matplot (x_axis, y_axis_heading, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("red","green","blue"),
	ylim = c(floor_y_heading,ceil_y_heading),
    main = "Magneto"
	)

legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)

matplot (x_axis, y_axis_gyro, type = "l", lty = 1, lwd = 1, pch = NULL,
     col = c("red","green","blue"),
	ylim = c(floor_y_gyro,ceil_y_gyro),
    main = "Gyroscope"
	)
legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)

matplot (x_axis, y_axis_acc, type = "l", lty = 1, lwd = 1, pch = NULL,
     	col = c("red","green","blue"),
	ylim = c(floor_y_acc,ceil_y_acc),
  	  main = "Accelerometer"
	)
legend("topleft", inset=.05, legend=c("x axis","y axis","z axis"), pch=1, col = c("red","green","blue"), horiz=FALSE)

dev.off()







