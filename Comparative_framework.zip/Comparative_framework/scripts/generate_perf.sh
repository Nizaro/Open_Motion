#!/bin/bash

echo PERFORMANCE GENERATOR

#get current directory
ROOT_DIR=`pwd`

dir_output=$2

#######################################
# function for float operation
#######################################

float_scale=5

function float_eval()
{
    local stat=0
    local result=0.0
    if [[ $# -gt 0 ]]; then
        result=$(echo "scale=$float_scale; $*" | bc -q 2>/dev/null)
        stat=$?
        if [[ $stat -eq 0  &&  -z "$result" ]]; then stat=1; fi
    fi
    echo $result
    return $stat
}


#######################################
# function for array
#######################################


#array pattern
array_pattern[0]="constant"
array_pattern[1]="echelon"
array_pattern[2]="sinus"

#array_noise
array_noise[0]="add_weak"
array_noise[1]="add_moderate"
array_noise[2]="add_strong"
#array_noise[3]="imp_weak"
#array_noise[4]="imp_moderate"
#array_noise[5]="imp_strong"

#array_type
array_type[0]="add"
#array_type[1]="imp"


#array strength
array_strength[0]="weak"
array_strength[1]="moderate"
array_strength[2]="strong"


array_method[0]="none"

function array_contains () { 
    local array="$1[@]"
    local seeking=$2
    local in=1
    for element in "${!array}"; do
        if [[ $element == $seeking ]]; then
            in=0
            break
        fi
    done
    return $in
}


echo List of methods 

index=0
nb_files=0



#get all method used
for data in $( ls $dir_output/base_files/error/*.csv ); do
	
	
	nb_files=$(( $nb_files + 1 ))
	
	#get absolute path
	real_path=`readlink -m $data`
			
	case $data in
		*test1_add_moderate_constant*) 
				name_method=`echo "$data" | cut -d'.' -f1`
				name_method=`echo "$name_method" | cut -d'_' -f8`
				echo $name_method
				array_method[$index]=$name_method
				index=$(( $index + 1 )) ;;
		*);;
	esac

done



nb_tests=$(( $nb_files / 9 ))
nb_tests=$(( $nb_tests / $index ))

echo number of tests $nb_tests 





#######################################
# Fusion of all file
#######################################

echo -ne Start fusion of all csv files... '\b'

#get first line
first_line='index'
first_line_angle='index,true_angle'
colums="1,"
colums_angle="1,2,"
colums_name=''
colums_name_angle='true_angle,'
method_name=''

for method in ${array_method[@]};do	

	first_line=$first_line','$method'_time'
	first_line=$first_line','$method'_error'
	
	first_line_angle=$first_line_angle','$method'_angle'
	
	colums_name=$colums_name''$method'_error,'
	colums_name_angle=$colums_name_angle''$method'_angle,'
	method_name=$method_name''$method','

done

colums_name=${colums_name::-1}
colums_name_angle=${colums_name_angle::-1}
method_name=${method_name::-1}


int_j=1
int_acc=2
int_acc_a=1

for (( j=1; j<=$index; j++ ))
do

	for (( l=1; l<=3; l++ ))
	do

		if [ $int_j -eq 3 ]
		then
		   int_j=1
		   colums_angle=$colums_angle"$int_acc_a,"
		else
		   int_j=$(( $int_j + 1))
		   colums=$colums"$int_acc,"
		   
		   
		fi
		
		int_acc=$(( $int_acc + 1))
		int_acc_a=$(( $int_acc_a + 1))
	done

done

		  
colums=${colums::-1}
colums_angle=${colums_angle::-1}




for (( i=1; i<=$nb_tests; i++ ))
do
	for noise in ${array_noise[@]};do
		for pattern in ${array_pattern[@]};do
		
				file_output_name='test'$i'_'$noise'_'$pattern'_fusion.csv'				
				file_output_name_resume='test'$i'_'$noise'_'$pattern'_resume.csv'				
				file_output_name_tmp='test'$i'_'$noise'_'$pattern'_tmp.csv'
				files_input_error=""
				files_input_angle=""

				for method in ${array_method[@]};do	

					files_input_error=$files_input_error" $dir_output/base_files/error/test"$i'_'$noise'_'$pattern'_'$method'.csv'
					files_input_angle=$files_input_angle" $dir_output/base_files/angle/test"$i'_'$noise'_'$pattern'_'$method'.csv'
					
				done	
				
				#fusion error
				csvjoin $files_input_error > "$dir_output/fusion/error/$file_output_name_tmp"
				csvcut -c $colums $dir_output/fusion/error/$file_output_name_tmp > "$dir_output/fusion/error/$file_output_name"
				
				rm $dir_output/fusion/error/$file_output_name_tmp
				
				sed -i 1d $dir_output/fusion/error/$file_output_name 
				
				cat <(echo $first_line) $dir_output/fusion/error/$file_output_name > $dir_output/fusion/error/$file_output_name.new
				mv $dir_output/fusion/error/$file_output_name.new $dir_output/fusion/error/$file_output_name
			
				$ROOT_DIR/scripts/generate_resume.r --input="$dir_output/fusion/error/$file_output_name" --output="$dir_output/fusion/resume_error/$file_output_name_resume" --method_name="$method_name" > /dev/null



				#fusion angle
				if [ $i -eq 1 ]
				then
					csvjoin $files_input_angle > "$dir_output/fusion/angle/$file_output_name_tmp"
					csvcut -c $colums_angle $dir_output/fusion/angle/$file_output_name_tmp > "$dir_output/fusion/angle/$file_output_name"
				
					rm $dir_output/fusion/angle/$file_output_name_tmp
				
					sed -i 1d $dir_output/fusion/angle/$file_output_name 
				
					cat <(echo $first_line_angle) $dir_output/fusion/angle/$file_output_name > $dir_output/fusion/angle/$file_output_name.new
					mv $dir_output/fusion/angle/$file_output_name.new $dir_output/fusion/angle/$file_output_name
				fi
		done
	done


done





echo DONE



#######################################
# Plotting error
#######################################


echo -ne Plotting error... '\b'

for file in $( ls $dir_output/fusion/error/*.csv ); do


	file_output=`basename "$file"`
	file_output=`echo "$file_output" | cut -d'.' -f1`


	
	case $file in
		*test1_*) $ROOT_DIR/scripts/plot_error.r --nb_method=$index --input="$file" --output="$dir_output/plots_error/$file_output.png" --method_name="$method_name" --column_name="$colums_name" > /dev/null;;
	esac


done

echo DONE

echo -ne Plotting angle... '\b'

index=$(( $index + 1))

for file in $( ls $dir_output/fusion/angle/*.csv ); do


	file_output=`basename "$file"`
	file_output=`echo "$file_output" | cut -d'.' -f1`

	case $file in
		*test1_*) $ROOT_DIR/scripts/plot_angle.r --nb_method=$index --input="$file" --output="$dir_output/plots_angle/$file_output.png" --method_name="true,$method_name" --column_name="$colums_name_angle" > /dev/null ;;
	esac


done

echo DONE



 

#######################################
# Generate Latex Table
#######################################

echo -ne Generate Latex file... '\b'


mkdir $dir_output/perfo/table
mkdir $dir_output/perfo/table/files


for data in $( ls $dir_output/fusion/resume_error/*.csv ); do

	#get absolute path
	real_path=`readlink -m $data`

	name_output=''

	case $real_path in
		*add*) name_output=$name_output'add_' ;;
		*imp*) name_output=$name_output'imp_' ;;
	esac

	case $real_path in
		*strong*) name_output=$name_output'strong' ;;
		*moderate*) name_output=$name_output'moderate' ;;
		*weak*) name_output=$name_output'weak' ;;
	esac


	#read all lines of the current file
	while read -r line
	do
	    
        case $line in
		*method_name*) ;;
		*)
		    #get method name
		    name_method=`echo "$line" | cut -d',' -f1`
			
		    #write line into the right file before fuse them
		    echo $line >> $dir_output'/perfo/files/tot_'$name_method'_'$name_output'.txt' ;;
	    esac
	    
	done < $real_path


done


for j in {1..4};do

	echo '\documentclass[12pt]{standalone}
	\usepackage{varwidth}

	\usepackage[utf8x]{inputenc}
	\usepackage[T1]{fontenc}

	\usepackage{amsmath, amssymb, graphics, setspace,tabularx}
	\newcommand{\mathsym}[1]{{}}
	\newcommand{\unicode}[1]{{}}
	\newcounter{mathematicapage}

	\begin{document}

	   \begin{varwidth}{100 in}
				\begin{tabular}{|c||c|c|c||}
			\hline
			 type & \multicolumn{3}{c||}{Additive}\\
			 \hline
			 strength & weak & moderate & strong\\
			 \hline' >> $dir_output"/perfo/table/files/table_s$j.tex"


	for method in ${array_method[@]};do
		echo '\hline
		' >> $dir_output"/perfo/table/files/table_s$j.tex"
		index=0
		line=''
		for noise in ${array_noise[@]};do
			

			for file in  $( ls  $dir_output/perfo/files/*.txt );do
				
				 case $file in
					*'tot_'$method*'_'*$noise*) 
						count=0.0
						score=0.0
						
						for row in $(cat $file); do
		
							 case $j in
								1)	mean_error=`echo $row | cut -d',' -f3`	
								    score=$(float_eval "$score + $mean_error");;
								    
								2)  mean_time=`echo $row | cut -d',' -f2`	
									mean_error=`echo $row | cut -d',' -f3`	
   							        tmp=$(float_eval "$mean_error * $mean_time")	
									tmp=$(float_eval "1.0 / $tmp")	
									score=$(float_eval "$score + $tmp");;
   
								3)	convergence=`echo $row | cut -d',' -f5`
									score=$(float_eval "$score + $convergence");;

								4)  wa=`echo $row | cut -d',' -f6`
									score=$(float_eval "$score + $wa");;
							esac
		

							count=$(float_eval "$count + 1.0")	
		
						done

						score=$(float_eval "$score / $count")	
						
						case $j in
						 2)score=$(float_eval "$score / 10000.0");;
						esac	
						
						line=$line' & '$score
					;;
				 esac
			done
			

		done
		

		echo $method ' '$line'\\
	\hline' >> $dir_output"/perfo/table/files/table_s$j.tex"

	done

	echo ' \end{tabular}
		\end{varwidth}
	\end{document}' >> $dir_output"/perfo/table/files/table_s$j.tex"

	pdflatex "$dir_output/perfo/table/files/table_s$j.tex" > /dev/null
	mv table_s$j.aux table_s$j.log table_s$j.pdf "$dir_output/perfo/table/files/"
	convert -density 600 "$dir_output/perfo/table/files/table_s$j.pdf" -quality 90 $dir_output"/perfo/table/table_s$j.png" > /dev/null 

done




echo DONE


#######################################
# histogram
#######################################

echo -ne Generate Histograms... '\b'
mkdir $dir_output/perfo/hist
mkdir $dir_output/perfo/hist/files


for type in ${array_type[@]};do

	echo "method,strength,value" >> $dir_output'/perfo/hist/files/histo_s1_'$type'.csv'
	echo "method,strength,value" >> $dir_output'/perfo/hist/files/histo_s2_'$type'.csv'
	echo "method,strength,value" >> $dir_output'/perfo/hist/files/histo_s3_'$type'.csv'
	echo "method,strength,value" >> $dir_output'/perfo/hist/files/histo_s4_'$type'.csv'

	for method in ${array_method[@]};do
		for strength in ${array_strength[@]};do
			
			count=0.0
			score_s1=0.0
			score_s2=0.0
			score_s3=0.0
			score_s4=0.0

			for data in $( ls $dir_output/perfo/files/*.txt ); do

				#get absolute path
				real_path=`readlink -m $data`


		
				case $real_path in
					*'tot_'$method*'_'*$type*$strength*)
						while read -r line 
						do
							mean_time=`echo $line | cut -d',' -f2`	
							mean_error=`echo $line | cut -d',' -f3`		
							var_error=`echo $line | cut -d',' -f4`
							convergence=`echo $line | cut -d',' -f5`
							wa=`echo $line | cut -d',' -f6`

							tmp=$(float_eval "$mean_error * $mean_time")	
							#tmp=$(float_eval "$tmp * $var_error")	
							
							score_s3=$(float_eval "$score_s3 + $convergence")
							score_s4=$(float_eval "$score_s4 + $wa")
							
							tmp=$(float_eval "1.0 / $tmp")	
							
							score_s1=$(float_eval "$score_s1 + $mean_error")	
							score_s2=$(float_eval "$score_s2 + $tmp")	
							count=$(float_eval "$count + 1.0")

						done < $real_path
					;;
				esac


			done

			score_s1=$(float_eval "$score_s1 / $count")
			score_s2=$(float_eval "$score_s2 / $count")	
			score_s2=$(float_eval "$score_s2 / 10000.0")
			score_s3=$(float_eval "$score_s3 / $count")
			score_s4=$(float_eval "$score_s4 / $count")
			
			case $strength in
				*weak*) tmp="a_" ;;
				*moderate*) tmp="b_" ;;
				*strong*) tmp="c_" ;;
			esac
			
			
			echo $method,$tmp$strength,$score_s1 >> $dir_output'/perfo/hist/files/histo_s1_'$type'.csv'
			echo $method,$tmp$strength,$score_s2 >> $dir_output'/perfo/hist/files/histo_s2_'$type'.csv'
			echo $method,$tmp$strength,$score_s3 >> $dir_output'/perfo/hist/files/histo_s3_'$type'.csv'
			echo $method,$tmp$strength,$score_s4 >> $dir_output'/perfo/hist/files/histo_s4_'$type'.csv'

		done
	done


	$ROOT_DIR/scripts/plot_hist.r --input=$dir_output"/perfo/hist/files/histo_s1_$type.csv" --output=$dir_output"/perfo/hist/histo_s1_$type.png" > /dev/null
	$ROOT_DIR/scripts/plot_hist.r --input=$dir_output"/perfo/hist/files/histo_s2_$type.csv" --output=$dir_output"/perfo/hist/histo_s2_$type.png" > /dev/null
	$ROOT_DIR/scripts/plot_hist.r --input=$dir_output"/perfo/hist/files/histo_s3_$type.csv" --output=$dir_output"/perfo/hist/histo_s3_$type.png" > /dev/null
	$ROOT_DIR/scripts/plot_hist.r --input=$dir_output"/perfo/hist/files/histo_s4_$type.csv" --output=$dir_output"/perfo/hist/histo_s4_$type.png" > /dev/null

done

echo DONE
