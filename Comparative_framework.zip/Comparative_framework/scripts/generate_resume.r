#!/usr/bin/Rscript

suppressMessages(library(limma))

## Collect arguments
args <- commandArgs(TRUE)


 
## Default setting when no arguments passed
if(length(args) < 1) {
  args <- c("--help")
}
 
## Help section
if("--help" %in% args) {
  cat("
      The R Script
 
      Arguments:    
      --method_name=c(name1,name2)
	  --output=
	  --input=
      --help") 
 
  q(save="no")
}
 
cat("\n")


specify_decimal <- function(x, k) format(round(x, k), nsmall=k)

## Parse arguments (we expect the form --arg=value)
parseArgs <- function(x) strsplit(sub("^--", "", x), "=")
argsDF <- as.data.frame(do.call("rbind", parseArgs(args)))
argsL <- as.list(as.character(argsDF$V2))
names(argsL) <- argsDF$V1

output_file=argsL$output
input_file=argsL$input
method_name <- unlist(strsplit(argsL$method_name, "[,]"))


file.create(as.character(output_file))

nb_method <- length(method_name)

array_lines <- c("method_name,mean_time,mean_error,standard_deviation_error")

name <- paste(method_name[1],"_error",sep="")

options("scipen"=100, "digits"=10)

for (i in 1:nb_method ) {

		
		error <- read.columns(input_file,paste(method_name[i],"_error",sep="") , sep = ",")
		com_time <- read.columns(input_file,paste(method_name[i],"_time",sep=""), sep = ",")
		mean_error <- mean(error[,paste(method_name[i],"_error",sep="")])
		mean_time <- mean(com_time[,paste(method_name[i],"_time",sep="")])
		sd_error <- sd(error[,paste(method_name[i],"_error",sep="")])
		
		line_i <- paste(as.character(method_name[i]),",",mean_time,",",as.character(mean_error),",",as.character(sd_error),sep="")
		
		array_lines <- cbind(array_lines,line_i)
}


writeLines(array_lines, as.character(output_file))


#write into file



