#!/bin/bash


#get current directory
cd ../
ROOT_DIR=`pwd`


if [ ! -d "$ROOT_DIR/bin" ]; then

	mkdir bin
	cd $ROOT_DIR/src

	echo  Compilation source file... 

	make

	mv performance_evaluation ../bin
	mv sensor_simulator ../bin

	echo DONE
else

	cd $ROOT_DIR/src

	echo -neCompilation source file... 

	make

	mv performance_evaluation ../bin
	mv sensor_simulator ../bin

	echo DONE

fi


cd $ROOT_DIR





#######################################
# SIMULATION
#######################################



#get absolute path
now=$(date +"%m-%d-%y_%T")
dir_output=`readlink -m $ROOT_DIR/results`/$now


#create all folder
mkdir $dir_output
mkdir $dir_output/base_files
mkdir $dir_output/base_files/angle
mkdir $dir_output/base_files/error
mkdir $dir_output/base_files/params
mkdir $dir_output/fusion
mkdir $dir_output/fusion/resume_error
mkdir $dir_output/fusion/error
mkdir $dir_output/fusion/angle
mkdir $dir_output/plots_error
mkdir $dir_output/plots_angle
mkdir $dir_output/perfo
mkdir $dir_output/perfo/files

echo START SIMULATION

if [ "$(ls -A $ROOT_DIR/data_set/csv/)" ]; then
	for data in $( ls $ROOT_DIR/data_set/csv/ ); do

		real_path=`readlink -m $ROOT_DIR/data_set/csv/$data`

		echo Simulation : $data
	
		write_angle="false"

		case $data in
			*test1*) write_angle="true" ;;
		esac

		$ROOT_DIR/bin/performance_evaluation -i ${real_path} -o $dir_output -a $write_angle

		echo ""
		echo DONE
	
	done
else
	echo 'No data set generated'
fi


echo END SIMULATION

$ROOT_DIR/scripts/generate_perf.sh -d $dir_output





