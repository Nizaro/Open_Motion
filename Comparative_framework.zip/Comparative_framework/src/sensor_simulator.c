/*
 * main_simulator.c
 *
 *  Created on: 19 Oct, 2016
 *      Author: thomas
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <err.h>
#include <openmotion/om.h>

typedef enum MotionPattern{
	CONSTANT,ECHELON,SINUS
}MotionPattern;

typedef enum NoiseType{
	ADDITIVE,IMPULSE
}NoiseType;


typedef enum NoiseStrength{
	WEAK,MODERATE,STRONG
}NoiseStrength;


typedef struct Parameters{

	omVector vector_translation;
	omAxisAngle axisangle_rotation;

	MotionPattern pattern;
	NoiseType noise_type;
	NoiseStrength noise_strength;

	double double_start_seed;

}Parameters;


typedef struct IMU{

	omVector _vector_true_position;
	omQuaternion _quaternion_true_orientation;

	omVector _vector_gyroscope;
	omVector _vector_accelerometer;
	omVector _vector_magnetometer;

	omVector _vector_x_axis;
	omVector _vector_y_axis;
	omVector _vector_z_axis;

	double _double_seed_gyro;
	double _double_seed_acc;
	double _double_seed_mag;

	double _double_variance_gyro;
	double _double_variance_acc;
	double _double_variance_mag;

	omVector _vector_bias_gyroscope;
	omVector _vector_bias_accelerometer;
	omVector _vector_bias_magnetometer;


}IMU;

struct Parameters parameters;
int int_index_test;
char* dir_output;

void translation(struct IMU *imu,struct omVector *delta);
void rotation_axisangle(struct IMU *imu,struct omAxisAngle *a);
void rotation_quaternion(struct IMU *imu,struct omQuaternion *q);
void generate_gyroscope(struct IMU *imu,struct omAxisAngle *relative_rotation,struct omQuaternion *orientation_relative);
void generate_accelerometer(struct IMU *imu);
void generate_magnetometer(struct IMU *imu);
void init_imu(struct IMU *imu);
void free_imu(struct IMU *imu);
void get_angular_velocity(struct omQuaternion *q_tp1,struct omQuaternion *q_t,struct omVector *out);
void add_pertubation(struct omVector *input,double mu,double sigma,double*);


void get_angular_velocity(struct omQuaternion *q_tp1,struct omQuaternion *q_t,struct omVector *out){


	omQuaternion dq;
	om_operator_quat_sub(q_tp1,q_t,&dq);
	om_operator_quat_scal_div(&dq,DELTA_T,&dq);

	omQuaternion r;
	omQuaternion q_tp1_inv;
	om_quat_inverse(q_tp1,&q_tp1_inv);

	om_operator_quat_mul(&dq,&q_tp1_inv,&r);
	om_operator_quat_scal_mul(&r,2.0,&r);

	om_quat_imaginary(&r,out);


}


void init_imu(struct IMU *imu){

	imu->_double_seed_gyro = 0.0;
	imu->_double_seed_acc = 10000.0;
	imu->_double_seed_mag = 20000.0;

	imu->_double_variance_gyro = 0.003623;
	imu->_double_variance_acc = 0.015;
	imu->_double_variance_mag = 0.0075;

	om_vector_create(&imu->_vector_x_axis,3,1.0,0.0,0.0);
	om_vector_create(&imu->_vector_y_axis,3,0.0,1.0,0.0);
	om_vector_create(&imu->_vector_z_axis,3,0.0,0.0,1.0);

	om_vector_create(&imu->_vector_true_position,3,4.0,0.0,0.0);
	om_quat_create(&imu->_quaternion_true_orientation,1.0,0.0,0.0,0.0);

	om_vector_create(&imu->_vector_gyroscope,3);
	om_vector_create(&imu->_vector_accelerometer,3);
	om_vector_create(&imu->_vector_magnetometer,3);

	om_vector_create(&imu->_vector_bias_gyroscope,3,0.0,0.0,0.0);
	om_vector_create(&imu->_vector_bias_accelerometer,3,0.0,0.0,0.0);
	om_vector_create(&imu->_vector_bias_magnetometer,3,0.0,0.0,0.0);


}


void free_imu(struct IMU *imu){

	om_vector_free(&imu->_vector_x_axis);
	om_vector_free(&imu->_vector_y_axis);
	om_vector_free(&imu->_vector_z_axis);

	om_vector_free(&imu->_vector_true_position);

	om_vector_free(&imu->_vector_gyroscope);
	om_vector_free(&imu->_vector_accelerometer);
	om_vector_free(&imu->_vector_magnetometer);

	om_vector_free(&imu->_vector_bias_gyroscope);
	om_vector_free(&imu->_vector_bias_accelerometer);
	om_vector_free(&imu->_vector_bias_magnetometer);

}




void translation(struct IMU *imu,struct omVector *delta){

	om_operator_vector_add(&imu->_vector_true_position,delta,&imu->_vector_true_position);

}

void rotation_axisangle(struct IMU *imu,struct omAxisAngle *a){

	omQuaternion q;

	om_convert_axisAngle2quaternion(a,&q);

	rotation_quaternion(imu,&q);

}

void rotation_quaternion(struct IMU *imu,struct omQuaternion *q){

	// update orientation
	om_operator_quat_mul(q,&imu->_quaternion_true_orientation,&imu->_quaternion_true_orientation);
	om_quat_normalize(&imu->_quaternion_true_orientation);

	// get initial referential frame
	omVector x_axis;
	omVector y_axis;
	omVector z_axis;

	om_vector_create(&x_axis,3,1.0,0.0,0.0);
	om_vector_create(&y_axis,3,0.0,1.0,0.0);
	om_vector_create(&z_axis,3,0.0,0.0,1.0);

	// apply rotation
	omQuaternion q_inv;
	om_quat_inverse(&imu->_quaternion_true_orientation,&q_inv);

	om_rotate_vector_quaternion(&q_inv,&x_axis,&imu->_vector_x_axis);
	om_rotate_vector_quaternion(&q_inv,&y_axis,&imu->_vector_y_axis);
	om_rotate_vector_quaternion(&q_inv,&z_axis,&imu->_vector_z_axis);

	// normalization
	om_vector_normalize(&imu->_vector_x_axis);
	om_vector_normalize(&imu->_vector_y_axis);
	om_vector_normalize(&imu->_vector_z_axis);


}

void generate_gyroscope(struct IMU *imu,struct omAxisAngle *relative_rotation,struct omQuaternion *orientation_relative){

	// generate random walk for bias
	omVector noise_bias;
	om_vector_create(&noise_bias,3);
	om_random_generateWhiteNoise(3,0.0,0.00000000031623,imu->_double_seed_gyro+10.0,&noise_bias);
	imu->_double_seed_gyro += 3.0;
	om_operator_vector_add(&imu->_vector_bias_gyroscope,&noise_bias,&imu->_vector_bias_gyroscope);


	omQuaternion old_orientation_relative;
	omQuaternion rot;

	om_quat_create(&old_orientation_relative,orientation_relative->_qw,orientation_relative->_qx,orientation_relative->_qy,orientation_relative->_qz);
	om_convert_axisAngle2quaternion(relative_rotation,&rot);
	
	om_operator_quat_mul(&rot,orientation_relative,orientation_relative);

	// get variation of orientation at time t
	omVector angular_velocity;
	om_vector_create(&angular_velocity,3);
	get_angular_velocity(orientation_relative,&old_orientation_relative,&angular_velocity);

	// add perturbation to system
	add_pertubation(&angular_velocity,0.0,imu->_double_variance_gyro,&imu->_double_seed_gyro);

	//update values
	om_operator_vector_add(&angular_velocity,&imu->_vector_bias_gyroscope,&imu->_vector_gyroscope);

	// free memory
	om_vector_free(&angular_velocity);
	om_vector_free(&noise_bias);

}




void generate_accelerometer(struct IMU *imu){

	// generate random walk for bias
	omVector noise_bias;
	om_vector_create(&noise_bias,3);
	om_random_generateWhiteNoise(3,0.0,0.00003,imu->_double_seed_acc+10.0,&noise_bias);
	imu->_double_seed_acc += 3.0;
	om_operator_vector_add(&imu->_vector_bias_accelerometer,&noise_bias,&imu->_vector_bias_accelerometer);


	omVector ned_gravity;
	omVector imu_gravity;

	om_vector_create(&ned_gravity,3,0.0,0.0,G);
	om_vector_create(&imu_gravity,3);


	om_rotate_vector_quaternion(&imu->_quaternion_true_orientation,&ned_gravity,&imu_gravity);

	// add perturbation to system
	add_pertubation(&imu_gravity,0.0,imu->_double_variance_acc,&imu->_double_seed_acc);

	//update values
	om_operator_vector_add(&imu_gravity,&imu->_vector_bias_accelerometer,&imu->_vector_accelerometer);

	// free memory
	om_vector_free(&ned_gravity);
	om_vector_free(&imu_gravity);


}

void generate_magnetometer(struct IMU *imu){

	// generate random walk for bias
	omVector noise_bias;
	om_vector_create(&noise_bias,3);
	om_random_generateWhiteNoise(3,0.0,0.000075,imu->_double_seed_mag+10.0,&noise_bias);
	imu->_double_seed_acc += 3.0;
	om_operator_vector_add(&imu->_vector_bias_magnetometer,&noise_bias,&imu->_vector_bias_magnetometer);


	omVector ned_magnetic;
	omVector imu_magnetic;

	om_vector_create(&ned_magnetic,3,0.9687632386,0.003889250977,-0.2479569747);
	om_vector_create(&imu_magnetic,3);


	om_rotate_vector_quaternion(&imu->_quaternion_true_orientation,&ned_magnetic,&imu_magnetic);

	// add perturbation to system
	add_pertubation(&imu_magnetic,0.0,imu->_double_variance_mag,&imu->_double_seed_mag);

	//update values
	om_operator_vector_add(&imu_magnetic,&imu->_vector_bias_magnetometer,&imu->_vector_magnetometer);

	// free memory
	om_vector_free(&ned_magnetic);
	om_vector_free(&imu_magnetic);



}


void add_pertubation(struct omVector *input,double mu,double sigma,double* seed){

	double double_strength;
	double alpha,beta;

	switch(parameters.noise_strength){

		case WEAK:
			double_strength = 4.0;
			break;

		case MODERATE:
			double_strength = 1.0;
			break;

		case STRONG:
			double_strength = 0.25;
			break;
	}


	/* random value */
	double value;

	for(int i=0;i<3;++i){
		switch(parameters.noise_type){

			/* gaussian additive noise */
			case ADDITIVE:

				/* white noise generation from Box-Muller method */
				value = om_random_normalDistribution(mu,sigma,*seed)/double_strength;

				/* add value to input vector */
				om_vector_setValue(input,i,om_vector_getValue(input,i) + value);

				break;

			/* gaussian impluse noise */
			case IMPULSE:


				/* white noise generation with a random high value */
				value = om_random_normalDistribution(mu,sigma,*seed)*(1.0 + (om_random_bernouilliDistribution(0.2,*seed+1000.0)*2.0))/double_strength;

				/* add value to input vector */
				om_vector_setValue(input,i,om_vector_getValue(input,i) + value);

				break;

		}

		*seed += 1.0;
	}

}




void readArgv(int argc,char** argv){

	for(int i=1; i < argc;i++){

		if(strcmp(argv[i],"-n") == 0)
			int_index_test = atoi(argv[i+1]);

		if(strcmp(argv[i],"-d") == 0)
			dir_output = argv[i+1];

		if(strcmp(argv[i],"-nt") == 0){
			if(strcmp(argv[i+1],"add") == 0){
				parameters.noise_type = ADDITIVE;
			}
			else if(strcmp(argv[i+1],"imp") == 0){
				parameters.noise_type = IMPULSE;
			}

		}

		if(strcmp(argv[i],"-ns") == 0){
			if(strcmp(argv[i+1],"weak") == 0){
				parameters.noise_strength = WEAK;
			}
			else if(strcmp(argv[i+1],"moderate") == 0){
				parameters.noise_strength = MODERATE;
			}
			else if(strcmp(argv[i+1],"strong") == 0){
				parameters.noise_strength = STRONG;
			}
		}

		if(strcmp(argv[i],"-p") == 0){
			if(strcmp(argv[i+1],"constant") == 0){
				parameters.pattern = CONSTANT;
			}
			else if(strcmp(argv[i+1],"echelon") == 0){
				parameters.pattern = ECHELON;
			}
			else if(strcmp(argv[i+1],"sinus") == 0){
				parameters.pattern = SINUS;
			}
		}

		if(strcmp(argv[i],"--axis") == 0){
			om_vector_create(&parameters.axisangle_rotation._axis,3,atof(argv[i+1]),atof(argv[i+2]),atof(argv[i+3]));
			om_vector_normalize(&parameters.axisangle_rotation._axis);

		}

		if(strcmp(argv[i],"--angle") == 0){
			parameters.axisangle_rotation._angle = atof(argv[i+1])*DEG_TO_RAD;
		}

	}

	om_vector_create(&parameters.vector_translation,3,0.0,0.0,0.0);




}


void applyChangement(struct IMU *imu,struct omAxisAngle *axis_angle, struct omVector *move,struct omQuaternion *orientation_estimate_gyro){

	/* translation of the sensor */
	translation(imu,move);


	/* */
	omVector axis_projection_camera;
	om_vector_create(&axis_projection_camera,3);
	om_rotate_vector_quaternion(&imu->_quaternion_true_orientation,&axis_angle->_axis,&axis_projection_camera);

	/* update real attitude */
	rotation_axisangle(imu,axis_angle);

	/* simulate gyroscope */
	omAxisAngle axis_angle_projection;
	om_vector_create(&axis_angle_projection._axis,3);
	om_vector_clone(&axis_projection_camera,&axis_angle_projection._axis);
	axis_angle_projection._angle = axis_angle->_angle;

	generate_gyroscope(imu,&axis_angle_projection,orientation_estimate_gyro);

	/* simulate accelerometer */
	generate_accelerometer(imu);

	/* simulate magnetometer */
	generate_magnetometer(imu);

}

void computeOutputFile(char** file_output){

	char str[10];
	sprintf(str, "test%d", int_index_test);
	strcpy(*file_output, dir_output);

	strcat(*file_output,str);

	switch(parameters.noise_type){
		case ADDITIVE:
			strcat(*file_output,"_add_");
			break;
		case IMPULSE:
			strcat(*file_output,"_imp_");
			break;
	}

	switch(parameters.noise_strength){
		case WEAK:
			strcat(*file_output,"weak_");
			break;
		case MODERATE:
			strcat(*file_output,"moderate_");
			break;
		case STRONG:
			strcat(*file_output,"strong_");
			break;

	}

	switch(parameters.pattern){
		case ECHELON:
			strcat(*file_output,"echelon.csv");
			break;
		case CONSTANT:
			strcat(*file_output,"constant.csv");
			break;
		case SINUS:
			strcat(*file_output,"sinus.csv");
			break;

	}




}



void process(int N){

	char* file_output = (char*)malloc(250*sizeof(char));
	memset(file_output, '\0', sizeof(file_output));

	double amplitude = 0.05;
	int bool_stop = 0;
	int echelon_cpt = 0;
	double copy_angle = parameters.axisangle_rotation._angle;

	computeOutputFile(&file_output);

	FILE *f_output = fopen(file_output, "w");
	fprintf(f_output, "time,truePositionX,truePositionY,truePositionZ,trueAttitudeQuatW,trueAttitudeQuatX,trueAttitudeQuatY,trueAttitudeQuatZ,simulGyroX,simulGyroY,simulGyroZ,simulAccX,simulAccY,simulAccZ,simulMagX,simulMagY,simulMagZ\n");

	IMU imu;
	init_imu(&imu);

	struct omQuaternion orientation_estimate_gyro;
	om_quat_create(&orientation_estimate_gyro,1.0,0.0,0.0,0.0);


	omAxisAngle axis_angle;
	om_vector_create(&axis_angle._axis,3,0.0,1.0,0.0);
	axis_angle._angle = -91.0*DEG_TO_RAD;

	rotation_axisangle(&imu,&axis_angle);

	if(f_output != NULL ){


			for(int i=0;i<N;i++){

				if(parameters.pattern == SINUS){

					double theta = DEG_TO_RAD*0.1*(double)( i );
					parameters.axisangle_rotation._angle = DEG_TO_RAD*((sin(theta)+1.0)*amplitude);
					
				}else if(parameters.pattern == ECHELON){

					/* constant angular velocity with random pics */
					if(bool_stop ){

						parameters.axisangle_rotation._angle = amplitude*DEG_TO_RAD;
						bool_stop = echelon_cpt < 500;
						echelon_cpt = bool_stop ? echelon_cpt+1 : 0;

					}else{
						parameters.axisangle_rotation._angle = copy_angle;
						if(om_random_bernouilliDistribution(0.001,i) == 1.0)
							bool_stop = 1;
						else
							bool_stop = 0;
					}
				}

				applyChangement(&imu,&parameters.axisangle_rotation,&parameters.vector_translation,&orientation_estimate_gyro);

				fprintf(f_output, "%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n",((double)(i))*DELTA_T,om_vector_getValue(&imu._vector_true_position,0),om_vector_getValue(&imu._vector_true_position,1),om_vector_getValue(&imu._vector_true_position,2),
																     imu._quaternion_true_orientation._qw,imu._quaternion_true_orientation._qx,imu._quaternion_true_orientation._qy,imu._quaternion_true_orientation._qz,
																	 om_vector_getValue(&imu._vector_gyroscope,0),om_vector_getValue(&imu._vector_gyroscope,1),om_vector_getValue(&imu._vector_gyroscope,2),
																	 om_vector_getValue(&imu._vector_accelerometer,0),om_vector_getValue(&imu._vector_accelerometer,1),om_vector_getValue(&imu._vector_accelerometer,2),
																	 om_vector_getValue(&imu._vector_magnetometer,0),om_vector_getValue(&imu._vector_magnetometer,1),om_vector_getValue(&imu._vector_magnetometer,2));


			}



	}
	fclose(f_output);



}



int main(int argc,char** argv){


	readArgv(argc,argv);

	process(60000);

}








