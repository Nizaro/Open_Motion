/*
 ============================================================================
 Name        : TestOpenMotion.c
 Author      : Jayzzu
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <err.h>
#include <openmotion/om.h>


#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"

typedef enum { FALSE, TRUE } bool;

// a common function used to free malloc'd objects
typedef void (*freeFunction)(void *);



///////////
// Linked list
///////////


typedef bool (*listIterator)(void *);

typedef struct _listNode {
  void *data;
  struct _listNode *next;
} listNode;

typedef struct {
  int logicalLength;
  int elementSize;
  listNode *head;
  listNode *tail;
  freeFunction freeFn;
} list;

void list_new(list *list, int elementSize, freeFunction freeFn);
void list_destroy(list *list);

void list_prepend(list *list, void *element);
void list_append(list *list, void *element);
int list_size(list *list);

void list_for_each(list *list, listIterator iterator);
void list_head(list *list, void *element, bool removeFromList);
void list_tail(list *list, void *element);


list params_est;

double calculErrorOrientation(omQuaternion *q_real,omQuaternion *q_est);

///////////
// IO Manager
///////////

extern char csvfile_input[];
extern char dir_output[];

struct line_reader {
    /* All members are private. */
    FILE    *f;
    char    *buf;
    size_t     siz;
};

char* next_line(struct line_reader *lr, size_t *len);
void lr_init(struct line_reader *lr, FILE *f);
void lr_free(struct line_reader *lr);
char** str_split(char* a_str, const char a_delim);





///////////
// FRAMEWORK
///////////


bool write_angle;

typedef enum MethodType{
    MEKF,REQUEST,QUEST,USQUE,CGO,PF,GDOF,CFA,CSP
}MethodType;


typedef union Filter{

    omNonLinearFilter_CGO filter_cgo;
    omNonLinearFilter_USQUE filter_usque;
    omNonLinearFilter_CSP filter_csp;
    omNonLinearFilter_MEKF filter_mekf;
    omNonLinearFilter_REQUEST filter_request;
    omNonLinearFilter_QUEST filter_quest;
    omNonLinearFilter_PF filter_pf;
    omNonLinearFilter_GDOF filter_gdof;
    omNonLinearFilter_CFA filter_cfa;


}Filter;


typedef struct Method{

    MethodType type;

    omSensorFusionManager manager;
    Filter filter;

    list list_error;
    list list_angle;
    list list_time;

}Method;


struct Groundtruth{

    omVector position;
    omQuaternion q_true;

};


Method* methods;
double* true_angle;




void displayLoadingBar(int index);
double signeOf(double d);

void read_args(int argc,char** argv);

char csvfile_input[128];
char dir_output[128];

///////////
// Linked list
///////////


void list_new(list *list, int elementSize, freeFunction freeFn)
{
  assert(elementSize > 0);
  list->logicalLength = 0;
  list->elementSize = elementSize;
  list->head = list->tail = NULL;
  list->freeFn = freeFn;
}

void list_destroy(list *list)
{
  listNode *current;
  while(list->head != NULL) {
    current = list->head;
    list->head = current->next;

    if(list->freeFn) {
      list->freeFn(current->data);
    }

    free(current->data);
    free(current);
  }
}

void list_prepend(list *list, void *element)
{
  listNode *node = malloc(sizeof(listNode));
  node->data = malloc(list->elementSize);
  memcpy(node->data, element, list->elementSize);

  node->next = list->head;
  list->head = node;

  // first node?
  if(!list->tail) {
    list->tail = list->head;
  }

  list->logicalLength++;
}

void list_append(list *list, void *element)
{
  listNode *node = malloc(sizeof(listNode));
  node->data = malloc(list->elementSize);
  node->next = NULL;

  memcpy(node->data, element, list->elementSize);

  if(list->logicalLength == 0) {
    list->head = list->tail = node;
  } else {
    list->tail->next = node;
    list->tail = node;
  }

  list->logicalLength++;
}

void list_for_each(list *list, listIterator iterator)
{
  assert(iterator != NULL);

  listNode *node = list->head;
  bool result = TRUE;
  while(node != NULL && result) {
    result = iterator(node->data);
    node = node->next;
  }
}

void list_head(list *list, void *element, bool removeFromList)
{
  assert(list->head != NULL);

  listNode *node = list->head;
  memcpy(element, node->data, list->elementSize);

  if(removeFromList) {
    list->head = node->next;
    list->logicalLength--;

    free(node->data);
    free(node);
  }
}

void list_tail(list *list, void *element)
{
  assert(list->tail != NULL);
  listNode *node = list->tail;
  memcpy(element, node->data, list->elementSize);
}

int list_size(list *list)
{
  return list->logicalLength;
}

///////////
// IO manager
///////////




/*
 * Initializes a line reader _lr_ for the stream _f_.
 */
void lr_init(struct line_reader *lr, FILE *f){
    lr->f = f;
    lr->buf = NULL;
    lr->siz = 0;
}

/*
 * Reads the next line. If successful, returns a pointer to the line,
 * and sets *len to the number of characters, at least 1. The result is
 * _not_ a C string; it has no terminating '\0'. The returned pointer
 * remains valid until the next call to next_line() or lr_free() with
 * the same _lr_.
 *
 * next_line() returns NULL at end of file, or if there is an error (on
 * the stream, or with memory allocation).
 */
char* next_line(struct line_reader *lr, size_t *len){

    size_t newsiz;
    int c;
    char *newbuf;

    *len = 0;            /* Start with empty line. */
    for (;;) {
        c = fgetc(lr->f);    /* Read next character. */
        if (ferror(lr->f))
            return NULL;

        if (c == EOF) {
            /*
             * End of file is also end of last line,
        `     * unless this last line would be empty.
             */
            if (*len == 0)
                return NULL;
            else
                return lr->buf;
        } else {
            /* Append c to the buffer. */
            if (*len == lr->siz) {
                /* Need a bigger buffer! */
                newsiz = lr->siz + 4096;
                newbuf = realloc(lr->buf, newsiz);
                if (newbuf == NULL)
                    return NULL;
                lr->buf = newbuf;
                lr->siz = newsiz;
            }
            lr->buf[(*len)++] = c;

            /* '\n' is end of line. */
            if (c == '\n')
                return lr->buf;
        }
    }
}

/*
 * Frees internal memory used by _lr_.
 */
void lr_free(struct line_reader *lr){
    free(lr->buf);
    lr->buf = NULL;
    lr->siz = 0;
}




char** str_split(char* a_str, const char a_delim)
{
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, delim);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }

    return result;
}


void displayLoadingBar(int index){

    double total = 60000.0;
    double percentage = ((double)(index) / total) * 100.0;

   printf("LOADING %.2f%%\r", percentage);
   fflush(stdout);
}

double signeOf(double d){
    return d > 0.0 ? 1.0 : -1.0;
}

double calculErrorOrientation(omQuaternion *q_real,omQuaternion *q_est){

    omQuaternion q_est_inv;
    omQuaternion dq;// = q_real*q_est.inverse();
    omVector dp;

    om_vector_create(&dp,3);
    om_quat_inverse(q_est,&q_est_inv);
    om_operator_quat_mul(q_real,&q_est_inv,&dq);

    double tmp = (4.0 * (signeOf(dq._qw)))/(1.0 + fabs(dq._qw));

    om_quat_imaginary(&dq,&dp);
    om_operator_vector_scal_mul(&dp,tmp,&dp);

    return om_vector_rms(&dp);

}

void read_args(int argc,char** argv){

    for(int i = 1; i < argc; ++i){

        if(strcmp(argv[i],"-i") == 0){
            strcpy(csvfile_input,argv[i+1]);
        }else if(strcmp(argv[i],"-o") == 0){
            strcpy(dir_output,argv[i+1]);
        }else if(strcmp(argv[i],"-a") == 0){
            if(strcmp(argv[i+1],"true") == 0){
                write_angle = TRUE;
            }else{
                write_angle = FALSE;
            }
        }

    }
}



// reverse the given null-terminated string in place
void reverse(char * str)
{
  if (str)
  {
    char * end = str + strlen(str) - 1;

    // swap the values in the two given variables
    // XXX: fails when a and b refer to same memory location
#   define XOR_SWAP(a,b) do\
    {\
      a ^= b;\
      b ^= a;\
      a ^= b;\
    } while (0)

    // walk inwards from both ends of the string,
    // swapping until we get to the middle
    while (str < end)
    {
      XOR_SWAP(*str, *end);
      str++;
      end--;
    }
#   undef XOR_SWAP
  }
}


void init_ned(){


    om_vector_create(&ned_magnetic_field,3,40.8101,0.1609,10.2636);
    om_vector_create(&ned_magnetic_field_normalized,3);
    om_vector_clone(&ned_magnetic_field, &ned_magnetic_field_normalized);
    om_vector_normalize(&ned_magnetic_field_normalized);

    om_vector_create(&ned_gravity,3,0.0,0.0,G);
    om_vector_create(&ned_gravity_normalized,3,0.0,0.0,1.0);

}



void displayTable(int nb_method,list* list_name,list* list_s1,list* list_s2,list* list_s3,list* list_s4){

    int* tab_index_best = (int*)malloc(4*sizeof(int));
    double best_s1 = 10.0;
    double best_s2 = 0.0;
    double best_s3 = 0.0;
    double best_s4 = 9999999.9;


    for(int i=0;i<nb_method;++i){

        double s1;
        double s2;
        double s3;
        double s4;
        char name[20];

        list_head(list_name,&name,TRUE);
        list_head(list_s1,&s1,TRUE);
        list_head(list_s2,&s2,TRUE);
        list_head(list_s3,&s3,TRUE);
        list_head(list_s4,&s4,TRUE);

        if(best_s1 > s1){
            tab_index_best[0] = i;
            best_s1 = s1;
        }

        if(best_s2 < s2){
            tab_index_best[1] = i;
            best_s2 = s2;
        }

        if(best_s3 < s3){
            tab_index_best[2] = i;
            best_s3 = s3;
        }

        if(best_s4 > s4){
            tab_index_best[3] = i;
            best_s4 = s4;
        }

        list_append(list_name,&name);
        list_append(list_s1,&s1);
        list_append(list_s2,&s2);
        list_append(list_s3,&s3);
        list_append(list_s4,&s4);


    }


    printf("+-----------+-------------+-------------+-------------+-------------+\n");
    printf("|  Method   |   score s1  |   score s2  |   score s3  |   score s4  |\n");

    for(int i=0;i<nb_method;++i){

        double s1;
        double s2;
        double s3;
        double s4;
        char name[20];


        list_head(list_name,&name,TRUE);
        list_head(list_s1,&s1,TRUE);
        list_head(list_s2,&s2,TRUE);
        list_head(list_s3,&s3,TRUE);
        list_head(list_s4,&s4,TRUE);

        //printf("|%9s  |  %2.7lf  |   %8.3lf  |  %2.7lf  |   %8.2lf  |\n", name, s1,s2,s3,s4);

        printf("+-----------+-------------+-------------+-------------+-------------+\n");
        printf("|%9s  ",name);

        if(i == tab_index_best[0]){
            printf("|");
            printf(KGRN "  %2.7lf  " KWHT,s1);
        }else{
            printf("|  %2.7lf  ",s1);
        }

        if(i == tab_index_best[1]){
            printf("|");
            printf(KGRN "   %8.3lf  " KWHT,s2);
        }else{
            printf("|   %8.3lf  ",s2);
        }

        if(i == tab_index_best[2]){
            printf("|");
            printf(KGRN "  %2.7lf  " KWHT,s3);
        }else{
            printf("|  %2.7lf  ",s3);
        }

        if(i == tab_index_best[3]){
            printf("|");
            printf(KGRN "   %8.2lf  " KWHT,s4);
            printf("|\n");
        }else{
            printf("|   %8.2lf  |\n",s4);
        }



    }

    printf("+-----------+-------------+-------------+-------------+-------------+\n");

    //printf("%7.1lf%11.0lf%\n", 100.1, 1221.0);
    //printf("%7.1lf%11.0lf%10.3lf\n", 2.3, 211.0, 214.0);


}



void saveParams(){

    printf("\nRESULTS\n");

    //creating output file
    reverse(csvfile_input);
    char** tokens = str_split(csvfile_input,'/');
    reverse(tokens[0]);
    char** tokens2 = str_split(tokens[0],'.');

    char dir_output_params[150];

    memset(dir_output_params, '\0', sizeof(dir_output_params));

    strcpy(dir_output_params, dir_output);
    

    strcat(dir_output_params,"/base_files/params/");
    strcat(dir_output_params,tokens2[0]);


	char file_output_params[150];
    memset(file_output_params, '\0', sizeof(file_output_params));
   
	strcpy(file_output_params, dir_output_params);
	strcat(file_output_params,"_params.csv");

	FILE *f_params = fopen(file_output_params, "w");
	

	if (f_params == NULL )
	{
		printf("Error opening file!\n");
		printf("file_output_error : %s\n",file_output_params);

		exit(1);
	}else{
		int size = list_size(&params_est);

		fprintf(f_params, "index,k_a,k_m\n");

		for(int i = 0; i<size;i++){

			omVector result;
			list_head(&params_est,&result,TRUE);

			fprintf(f_params, "%d,%f,%f\n",i,om_vector_getValue(&result,0),om_vector_getValue(&result,1));
		}

		fclose(f_params);
	}


}





void saveMethodResults(int nb_method){

    printf("\nRESULTS\n");

    //creating output file
    char csvfile_input_cpy[150];
    memset(csvfile_input_cpy, '\0', sizeof(csvfile_input_cpy));
    
    strcpy(csvfile_input_cpy, csvfile_input);
    
    
    reverse(csvfile_input_cpy);
    char** tokens = str_split(csvfile_input_cpy,'/');
    reverse(tokens[0]);
    char** tokens2 = str_split(tokens[0],'.');

    char dir_output_error[150];
    char dir_output_angle[150];

    memset(dir_output_error, '\0', sizeof(dir_output_error));
    memset(dir_output_angle, '\0', sizeof(dir_output_angle));

    strcpy(dir_output_error, dir_output);
    strcpy(dir_output_angle, dir_output);

    strcat(dir_output_error,"/base_files/error/");
    strcat(dir_output_error,tokens2[0]);

    strcat(dir_output_angle,"/base_files/angle/");
    strcat(dir_output_angle,tokens2[0]);

    list list_names;
    list list_s1;
    list list_s2;
    list list_s3;
    list list_s4;

    list_new(&list_names,sizeof(char**),NULL);
    list_new(&list_s1,sizeof(double),NULL);
    list_new(&list_s2,sizeof(double),NULL);
    list_new(&list_s3,sizeof(double),NULL);
    list_new(&list_s4,sizeof(double),NULL);

    for(int l=0;l<nb_method;l++){

        char name[20];
        char file_output_error[150];
        char file_output_angle[150];

        memset(name, '\0', sizeof(name));
        memset(file_output_error, '\0', sizeof(file_output_error));
        memset(file_output_angle, '\0', sizeof(file_output_angle));

        strcpy(file_output_error, dir_output_error);
        strcpy(file_output_angle, dir_output_angle);

        switch(methods[l].type){

        case USQUE:
            strcat(file_output_error,"_usque.csv");
            strcat(file_output_angle,"_usque.csv");
            strcpy(name, "usque");
            break;

        case CSP:
            strcat(file_output_error,"_csp.csv");
            strcat(file_output_angle,"_csp.csv");
            strcpy(name, "csp");
            break;


        case MEKF:
            strcat(file_output_error,"_mekf.csv");
            strcat(file_output_angle,"_mekf.csv");
            strcpy(name, "mekf");

            break;
        case CGO:
            strcat(file_output_error,"_cgo.csv");
            strcat(file_output_angle,"_cgo.csv");
            strcpy(name, "cgo");

            break;

        case REQUEST:
            strcat(file_output_error,"_request.csv");
            strcat(file_output_angle,"_request.csv");
            strcpy(name, "request");
            break;

        case PF:
            strcat(file_output_error,"_pf.csv");
            strcat(file_output_angle,"_pf.csv");
            strcpy(name, "pf");
            break;

        case GDOF:
            strcat(file_output_error,"_gdof.csv");
            strcat(file_output_angle,"_gdof.csv");
            strcpy(name, "gdof");
            break;

        case CFA:
            strcat(file_output_error,"_cfa.csv");
            strcat(file_output_angle,"_cfa.csv");
            strcpy(name, "cfa");
            break;


        case QUEST:
            strcat(file_output_error,"_quest.csv");
            strcat(file_output_angle,"_quest.csv");
            strcpy(name, "quest");
            break;


        default:
            strcat(file_output_error,"_usque.csv");
            strcat(file_output_angle,"_usque.csv");
            strcpy(name, "usque");
            break;

        }


        FILE *f_error = fopen(file_output_error, "w");
        FILE *f_angle;

        if(write_angle == TRUE)
            f_angle = fopen(file_output_angle, "w");

        double mean_error = 0.0;
        double mean_time = 0.0;
        double mean_lambda = 0.0;
        double s4 = 0.0;
        double T_i = 0.0;
        double e_0 = 0.0;
        double old_error = 0.0;

        int n = 500;
        int size = list_size(&methods[l].list_error);
        int size_angle = list_size(&methods[l].list_angle);

        if (f_error == NULL || (f_angle == NULL && write_angle == TRUE ))
        {
            printf("Error opening file!\n");
            printf("file_output_error : %s\n",file_output_error);
            printf("file_output_angle : %s\n",file_output_angle);
            exit(1);
        }else{

            fprintf(f_error, "index,time,error\n");

            if(write_angle == TRUE)
                fprintf(f_angle, "index,true_angle,angle\n");


            for(int i = 0; i<size;i++){

                double error;
                double time;


                list_head(&methods[l].list_error,&error,TRUE);
                list_head(&methods[l].list_time,&time,TRUE);

                if(i<size_angle && write_angle == TRUE){

                    double angle;
                    list_head(&methods[l].list_angle,&angle,TRUE);
                    fprintf(f_angle, "%d,%f,%f\n",i,true_angle[i],angle);

                }

                fprintf(f_error, "%d,%f,%f\n",i,time,error);

                if(i>0 && i<n){
                    mean_lambda += ((-1.0)/(T_i))*log( error / e_0 );

                    double diff = error - old_error;
                    s4 += diff < 0.0 ? (diff*(-1.0)) : diff;
                    old_error = error;

                }else if(i>0){

                    double diff = error - old_error;
                    s4 += diff < 0.0 ? (diff*(-1.0)) : diff;
                    old_error = error;

                }else{

                    e_0 = error;
                    old_error = error;
                }

                T_i += DELTA_T;
                mean_error += error;
                mean_time += time;

            }

            mean_error /= (double)(size);
            mean_time /= (double)(size);
            mean_lambda /= (double)(n);

            fclose(f_error);
        }

        double s2 = 1.0/(mean_time*mean_error*10000.0);

        list_append(&list_names,&name);
        list_append(&list_s1,&mean_error);
        list_append(&list_s2,&s2);
        list_append(&list_s3,&mean_lambda);
        list_append(&list_s4,&s4);


    }


    displayTable(nb_method,&list_names,&list_s1,&list_s2,&list_s3,&list_s4);
}






void free_methods(int nb_method){

    for(int l=0;l<nb_method;l++){
        switch(methods[l].type){

            case USQUE:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_usque);
                break;

            case CSP:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_csp);
                break;

            case MEKF:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_mekf);
                break;

            case CGO:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_cgo);
                break;

            case REQUEST:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_request);
                break;

            case QUEST:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_quest);
                break;

            case PF:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_pf);
                break;
            
            case GDOF:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_gdof);
                break;

            case CFA:
                methods[l].manager.free_filter((void*)&methods[l].filter.filter_cfa);
                break;


            default:

                break;

        }

    }

}




void init_methods(int num,...){

    init_ned();

    methods = (Method*)malloc(num*sizeof(Method));

    omEulerAngle euler;
    euler._pitch = 50.0*DEG_TO_RAD;
    euler._roll = 50.0*DEG_TO_RAD;
    euler._yaw = 50.0*DEG_TO_RAD;

    va_list arguments;
    va_start ( arguments, num );

    for ( int x = 0; x < num; x++ ){        // Loop until all numbers are added

        char* name = va_arg ( arguments, char* ); // Adds the next value in argument list to sum.

        om_vector_create(&methods[x].manager.imu_params.bias_gyroscope,3,0.000031623,0.000031623,0.000031623);
        om_vector_create(&methods[x].manager.imu_params.bias_accelerometer,3,0.0,0.0,0.0);
        om_vector_create(&methods[x].manager.imu_params.bias_magnetometer,3,0.0,0.0,0.0);

        //methods[x].manager.imu_params.variance_gyroscope = 0.00031623;
        //methods[x].manager.imu_params.variance_accelerometer = 0.075;
        //methods[x].manager.imu_params.variance_magnetometer = 0.005;


        methods[x].manager.imu_params.variance_gyroscope = 0.031623;
        methods[x].manager.imu_params.variance_accelerometer = 0.75;
        methods[x].manager.imu_params.variance_magnetometer = 0.075;


        methods[x].manager.type = Quarternion;
        om_convert_euler2quaternion(&euler,&methods[x].manager.output.quaternion);

        list_new(&methods[x].list_error,sizeof(double),NULL);
        list_new(&methods[x].list_time,sizeof(double),NULL);
        list_new(&methods[x].list_angle,sizeof(double),NULL);

        if(strcmp(name,"usque") == 0){

            methods[x].type = USQUE;
            methods[x].manager.initialization_filter = &om_usque_initialization;
            methods[x].manager.process_filter = &om_usque_process;
            methods[x].manager.free_filter = &om_usque_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_usque);

            //methods[x].filter.filter_usque._lambda = 2.0;
        }else if(strcmp(name,"csp") == 0){

            methods[x].type = CSP;
            methods[x].manager.initialization_filter = &om_csp_initialization;
            methods[x].manager.process_filter = &om_csp_process;
            methods[x].manager.free_filter = &om_csp_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_csp);

            //methods[x].filter.filter_csp._lambda = 2.0;


        }else if(strcmp(name,"mekf") == 0){

            methods[x].type = MEKF;
            methods[x].manager.initialization_filter = &om_mekf_initialization;
            methods[x].manager.process_filter = &om_mekf_process;
            methods[x].manager.free_filter = &om_mekf_free;
            
			//methods[x].manager.imu_params.variance_accelerometer = 0.2;
			//methods[x].manager.imu_params.variance_magnetometer = 0.02;

            
            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_mekf);

        }else if(strcmp(name,"quest") == 0){

            methods[x].type = QUEST;
            methods[x].manager.initialization_filter = &om_quest_initialization;
            methods[x].manager.process_filter = &om_quest_process;
            methods[x].manager.free_filter = &om_quest_free;
            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_quest);

        }else if(strcmp(name,"cgo") == 0){

            methods[x].type = CGO;
            methods[x].manager.initialization_filter = &om_cgo_initialization;
            methods[x].manager.process_filter = &om_cgo_process;
            methods[x].manager.free_filter = &om_cgo_free;
            
            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_cgo);

			methods[x].filter.filter_cgo._k_acc = 1.0;
			methods[x].filter.filter_cgo._k_mag = 1.0;

        }
		else if(strcmp(name,"request") == 0){

            methods[x].type = REQUEST;
            methods[x].manager.initialization_filter = &om_request_initialization;
            methods[x].manager.process_filter = &om_request_process;
            methods[x].manager.free_filter = &om_request_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_request);

        }else if(strcmp(name,"pf") == 0){

            methods[x].type = PF;
            methods[x].manager.initialization_filter = &om_pf_initialization;
            methods[x].manager.process_filter = &om_pf_process;
            methods[x].manager.free_filter = &om_pf_free;

            //methods[x].manager.imu_params.variance_gyroscope = 0.0031623;
			methods[x].manager.imu_params.variance_gyroscope = 0.31623;
			//methods[x].manager.imu_params.variance_accelerometer = 0.75;
			//methods[x].manager.imu_params.variance_magnetometer = 0.75;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_pf);

        }
        else if(strcmp(name,"gdof") == 0){

            methods[x].type = GDOF;
            methods[x].manager.initialization_filter = &om_gdof_initialization;
            methods[x].manager.process_filter = &om_gdof_process;
            methods[x].manager.free_filter = &om_gdof_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_gdof);

        }

        else if(strcmp(name,"cfa") == 0){

            methods[x].type = CFA;
            methods[x].manager.initialization_filter = &om_cfa_initialization;
            methods[x].manager.process_filter = &om_cfa_process;
            methods[x].manager.free_filter = &om_cfa_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_cfa);

        }



        else if(strcmp(name,"switch-cfa") == 0){

            methods[x].type = SWITCH_CFA;
            methods[x].manager.initialization_filter = &om_usque_initialization;
            methods[x].manager.process_filter = &om_usque_process;
            methods[x].manager.free_filter = &om_usque_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_usque);

        }
        else if(strcmp(name,"switch-gdof") == 0){

            methods[x].type = SWITCH_GDOF;
            methods[x].manager.initialization_filter = &om_usque_initialization;
            methods[x].manager.process_filter = &om_usque_process;
            methods[x].manager.free_filter = &om_usque_free;

            methods[x].manager.initialization_filter(&methods[x].manager,&methods[x].filter.filter_usque);

        }



    }

}





void process(int nb_method){

    struct line_reader lr;
    FILE *f;
    size_t len;
    char *line;

    struct timeval tbegin_tot,tend_tot;


    f = fopen(csvfile_input, "r");
    if (f == NULL) {
        perror(csvfile_input);
        exit(1);
    }

    lr_init(&lr, f);

    struct Groundtruth gt;
    om_vector_create(&gt.position,3);

    int NB_ANGLE = 2000;

    if(write_angle == TRUE)
        true_angle = (double*)malloc(NB_ANGLE*sizeof(double));


    int index = 0;

    // Start timer
    gettimeofday(&tbegin_tot,NULL);

    while ( (line = next_line(&lr, &len))) {

        char** tokens;

        tokens = str_split(line, ',');

        if(index == 0){
            for(int l=0;l<nb_method;l++){
                om_vector_create(&methods[l].manager.imu_data.data_accelerometer,3,0.0,0.0,0.0);
                om_vector_create(&methods[l].manager.imu_data.data_magnetometer,3,0.0,0.0,0.0);
                om_vector_create(&methods[l].manager.imu_data.data_gyroscope,3,0.0,0.0,0.0);

            }

        }else if(index == 1){

            for(int l=0;l<nb_method;l++)
                om_vector_setValues(&methods[l].manager.imu_data.data_gyroscope,3,atof(tokens[8]),atof(tokens[9]),atof(tokens[10]));
        }
        else if (tokens)
        {
            // get ground truth
            om_vector_setValues(&gt.position,3,atof(tokens[1]),atof(tokens[2]),atof(tokens[3]));
            om_quat_create(&gt.q_true,atof(tokens[4]),atof(tokens[5]),atof(tokens[6]),atof(tokens[7]));



            //for all methods
            for(int l=0;l<nb_method;l++){

                // set data
                om_vector_setValues(&methods[l].manager.imu_data.data_accelerometer,3,atof(tokens[11]),atof(tokens[12]),atof(tokens[13]));
                om_vector_setValues(&methods[l].manager.imu_data.data_magnetometer,3,atof(tokens[14]),atof(tokens[15]),atof(tokens[16]));
                //om_vector_normalize(&methods[l].manager.imu_data.data_magnetometer);

                // Variables
                double texec=0.0;
                struct timeval tbegin,tend;

                // Start timer
                gettimeofday(&tbegin,NULL);

                switch(methods[l].type){

                    case USQUE:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_usque);
                        break;

                    case MEKF:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_mekf);
                        break;

                    case CSP:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_csp);
                        break;

                    case CGO:
                            methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_cgo);
                        break;

                    case REQUEST:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_request);
                        break;

                    case QUEST:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_quest);
                        break;

                    case PF:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_pf);
                        break;

                    case GDOF:
                            methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_gdof);
                        break;

                    case CFA:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_cfa);
                        break;



                    default:
                        methods[l].manager.process_filter(&methods[l].manager,(void*)&methods[l].filter.filter_usque);
                        break;

                }

                // Stop timer
                gettimeofday(&tend,NULL);


                // Compute execution time
                texec=((double)(1000.0*(tend.tv_sec-tbegin.tv_sec)+((tend.tv_usec-tbegin.tv_usec)/1000.0)))/1000.0;

                // Compute error attitude
                double error = calculErrorOrientation(&gt.q_true,&methods[l].manager.output.quaternion);



                //save results
                list_append(&methods[l].list_error,&error);
                list_append(&methods[l].list_time,&texec);

                //if writing file angle
                if(index-2 < NB_ANGLE && write_angle == TRUE){

                    omAxisAngle aa;
                    om_convert_quaternion2axisAngle(&methods[l].manager.output.quaternion,&aa);
                    list_append(&methods[l].list_angle,&aa._angle);
                    om_vector_free(&aa._axis);
                }

                om_vector_setValues(&methods[l].manager.imu_data.data_gyroscope,3,atof(tokens[8]),atof(tokens[9]),atof(tokens[10]));
            }

            for (int i = 0; *(tokens + i); i++)
                free(*(tokens + i));


            free(tokens);
        }

        if(index > 2 && index-2 < NB_ANGLE && write_angle == TRUE){

            omAxisAngle aa;
            om_convert_quaternion2axisAngle(&gt.q_true,&aa);
            true_angle[index-2] = aa._angle;
            om_vector_free(&aa._axis);
        }


        index++;

        displayLoadingBar(index);
    }

    // Stop timer
    gettimeofday(&tend_tot,NULL);

    // Compute execution time
    double texec_tot=((double)(1000.0*(tend_tot.tv_sec-tbegin_tot.tv_sec)+((tend_tot.tv_usec-tbegin_tot.tv_usec)/1000.0)))/1000.0;

    printf("\n");
    printf("DONE\n");
    printf("Total Time : %f sec\n",texec_tot);

    if (!feof(f)) {
        perror("next_line");
        exit(1);
    }

    //free file reader
    lr_free(&lr);

    //free methods
    free_methods(nb_method);
    printf("Filter(s) memory allocated has been released\n");

    //export result into .csv file
    saveMethodResults(nb_method);

	saveParams();

}



int main(int argc,char** argv) {
	
	DELTA_T = 0.03;

	list_new(&params_est,sizeof(omVector),(freeFunction)&om_vector_free);
		
    //init file path
    csvfile_input[0]='\0';
    dir_output[0]='\0';

    // read the arguments
    read_args(argc,argv);

    // initialization of the chosen methods
    int nb_method = 8;
    init_methods(nb_method,"gdof","request","quest","usque","csp","cgo","cfa","mekf","pf","switch");

    // process the performance evaluation
    process(nb_method);


    return EXIT_SUCCESS;

}
